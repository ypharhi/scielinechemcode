-----------------------------------------------
-- Export file for user SKYLINE_FORM_FT      --
-- Created by comply on 05/12/2021, 18:50:14 --
-----------------------------------------------

spool db_min_obj.log

prompt
prompt Creating table DR$SEARCH_IDX$I
prompt ==============================
prompt
create table DR$SEARCH_IDX$I
(
  token_text  VARCHAR2(64) not null,
  token_type  NUMBER(3) not null,
  token_first NUMBER(10) not null,
  token_last  NUMBER(10) not null,
  token_count NUMBER(10) not null,
  token_info  BLOB
)
;
create index DR$SEARCH_IDX$X on DR$SEARCH_IDX$I (TOKEN_TEXT, TOKEN_TYPE, TOKEN_FIRST, TOKEN_LAST, TOKEN_COUNT)
  compress 2;

prompt
prompt Creating table DR$SEARCH_IDX$K
prompt ==============================
prompt
create table DR$SEARCH_IDX$K
(
  docid   NUMBER(38),
  textkey ROWID not null,
  primary key (TEXTKEY)
)
organization index;

prompt
prompt Creating table DR$SEARCH_IDX$N
prompt ==============================
prompt
create table DR$SEARCH_IDX$N
(
  nlt_docid NUMBER(38) not null,
  nlt_mark  CHAR(1) not null,
  primary key (NLT_DOCID)
)
organization index;

prompt
prompt Creating table DR$SEARCH_IDX$R
prompt ==============================
prompt
create table DR$SEARCH_IDX$R
(
  row_no NUMBER(3),
  data   BLOB
)
;

prompt
prompt Creating table D_PIVOT_TMP
prompt ==========================
prompt
create table D_PIVOT_TMP
(
  row_id             NUMBER,
  row_id_order       NUMBER,
  col_id             VARCHAR2(300),
  col_name           VARCHAR2(300),
  result             VARCHAR2(300),
  user_id            NUMBER,
  session_id         VARCHAR2(300),
  time_stamp_cleanup DATE,
  row_name           VARCHAR2(500)
)
;

prompt
prompt Creating table FG_ACCESS_LOG
prompt ============================
prompt
create table FG_ACCESS_LOG
(
  user_id     NUMBER,
  station_ip  VARCHAR2(50),
  time_stamp  DATE,
  success_ind VARCHAR2(3),
  ts_in_info  VARCHAR2(500)
)
;
comment on column FG_ACCESS_LOG.ts_in_info
  is '+ for test cache';

prompt
prompt Creating table FG_ACTIVITY_LOG
prompt ==============================
prompt
create table FG_ACTIVITY_LOG
(
  formid          VARCHAR2(500),
  timestamp       DATE,
  user_id         VARCHAR2(500),
  activitylogtype VARCHAR2(500),
  changevalue     VARCHAR2(1000),
  status          VARCHAR2(100),
  location        VARCHAR2(4000),
  startdate       DATE,
  enddate         DATE,
  additionalinfo  VARCHAR2(4000),
  leveltype       VARCHAR2(500),
  stacktrace      VARCHAR2(4000),
  timestamp3      TIMESTAMP(6) default systimestamp,
  comments        CLOB
)
;
comment on column FG_ACTIVITY_LOG.changevalue
  is 'not needed';
comment on column FG_ACTIVITY_LOG.status
  is 'not needed';
comment on column FG_ACTIVITY_LOG.location
  is 'not needed';
comment on column FG_ACTIVITY_LOG.startdate
  is 'not needed';
comment on column FG_ACTIVITY_LOG.enddate
  is 'not needed';
comment on column FG_ACTIVITY_LOG.additionalinfo
  is 'json';

prompt
prompt Creating table FG_ACTIVITY_LOG_HST
prompt ==================================
prompt
create table FG_ACTIVITY_LOG_HST
(
  formid          VARCHAR2(500),
  timestamp       DATE,
  user_id         VARCHAR2(500),
  activitylogtype VARCHAR2(500),
  changevalue     VARCHAR2(1000),
  status          VARCHAR2(100),
  location        VARCHAR2(4000),
  startdate       DATE,
  enddate         DATE,
  additionalinfo  VARCHAR2(4000),
  leveltype       VARCHAR2(500),
  stacktrace      VARCHAR2(4000),
  timestamp3      TIMESTAMP(6),
  comments        CLOB
)
;

prompt
prompt Creating table FG_AUTHEN_REPORT_V
prompt =================================
prompt
create table FG_AUTHEN_REPORT_V
(
  user_id NUMBER,
  product VARCHAR2(50),
  name    VARCHAR2(50),
  site    VARCHAR2(50)
)
;

prompt
prompt Creating table FG_CHEM_CAS_API_LOG
prompt ==================================
prompt
create table FG_CHEM_CAS_API_LOG
(
  material_form_id NUMBER,
  user_id          NUMBER,
  time_stamp       DATE,
  result           CLOB,
  resultid         VARCHAR2(500)
)
;

prompt
prompt Creating table FG_CHEM_DELETED_SEARCH
prompt =====================================
prompt
create table FG_CHEM_DELETED_SEARCH
(
  cd_id                NUMBER(10) not null,
  cd_structure         BLOB not null,
  cd_smiles            VARCHAR2(4000),
  cd_formula           VARCHAR2(100),
  cd_sortable_formula  VARCHAR2(500),
  cd_molweight         FLOAT,
  cd_hash              NUMBER(10) not null,
  cd_flags             VARCHAR2(20),
  cd_timestamp         DATE not null,
  cd_pre_calculated    NUMBER(1) default 0 not null,
  cd_taut_hash         NUMBER(10) not null,
  cd_taut_frag_hash    VARCHAR2(4000),
  cd_screen_descriptor VARCHAR2(4000),
  cd_fp1               NUMBER(10) not null,
  cd_fp2               NUMBER(10) not null,
  cd_fp3               NUMBER(10) not null,
  cd_fp4               NUMBER(10) not null,
  cd_fp5               NUMBER(10) not null,
  cd_fp6               NUMBER(10) not null,
  cd_fp7               NUMBER(10) not null,
  cd_fp8               NUMBER(10) not null,
  cd_fp9               NUMBER(10) not null,
  cd_fp10              NUMBER(10) not null,
  cd_fp11              NUMBER(10) not null,
  cd_fp12              NUMBER(10) not null,
  cd_fp13              NUMBER(10) not null,
  cd_fp14              NUMBER(10) not null,
  cd_fp15              NUMBER(10) not null,
  cd_fp16              NUMBER(10) not null,
  formid               VARCHAR2(100),
  fullformcode         VARCHAR2(100),
  moltype              VARCHAR2(100),
  elementid            VARCHAR2(100)
)
;
alter table FG_CHEM_DELETED_SEARCH
  add primary key (CD_ID);
create index FG_CHEM_DELETED_SEARCH_FX on FG_CHEM_DELETED_SEARCH (CD_SORTABLE_FORMULA);
create index FG_CHEM_DELETED_SEARCH_HX on FG_CHEM_DELETED_SEARCH (CD_HASH);
create index FG_CHEM_DELETED_SEARCH_PX on FG_CHEM_DELETED_SEARCH (CD_PRE_CALCULATED);
create index FG_CHEM_DELETED_SEARCH_THX on FG_CHEM_DELETED_SEARCH (CD_TAUT_HASH);

prompt
prompt Creating table FG_CHEM_DELETED_SEARCH_UL
prompt ========================================
prompt
create table FG_CHEM_DELETED_SEARCH_UL
(
  update_id   NUMBER(10) not null,
  update_info VARCHAR2(120) not null,
  cache_id    VARCHAR2(32) not null
)
;
alter table FG_CHEM_DELETED_SEARCH_UL
  add primary key (UPDATE_ID);
create index FG_CHEM_DELETED_SEARCH_CX on FG_CHEM_DELETED_SEARCH_UL (CACHE_ID);

prompt
prompt Creating table FG_CHEM_DOC_SEARCH
prompt =================================
prompt
create table FG_CHEM_DOC_SEARCH
(
  cd_id                NUMBER(10) not null,
  cd_structure         BLOB not null,
  cd_smiles            VARCHAR2(4000),
  cd_formula           VARCHAR2(100),
  cd_sortable_formula  VARCHAR2(500),
  cd_molweight         FLOAT,
  cd_hash              NUMBER(10) not null,
  cd_flags             VARCHAR2(20),
  cd_timestamp         DATE not null,
  cd_pre_calculated    NUMBER(1) default 0 not null,
  cd_taut_hash         NUMBER(10) not null,
  cd_taut_frag_hash    VARCHAR2(4000),
  cd_screen_descriptor VARCHAR2(4000),
  cd_fp1               NUMBER(10) not null,
  cd_fp2               NUMBER(10) not null,
  cd_fp3               NUMBER(10) not null,
  cd_fp4               NUMBER(10) not null,
  cd_fp5               NUMBER(10) not null,
  cd_fp6               NUMBER(10) not null,
  cd_fp7               NUMBER(10) not null,
  cd_fp8               NUMBER(10) not null,
  cd_fp9               NUMBER(10) not null,
  cd_fp10              NUMBER(10) not null,
  cd_fp11              NUMBER(10) not null,
  cd_fp12              NUMBER(10) not null,
  cd_fp13              NUMBER(10) not null,
  cd_fp14              NUMBER(10) not null,
  cd_fp15              NUMBER(10) not null,
  cd_fp16              NUMBER(10) not null
)
;
alter table FG_CHEM_DOC_SEARCH
  add primary key (CD_ID);
create index FG_CHEM_DOC_SEARCH_FX on FG_CHEM_DOC_SEARCH (CD_SORTABLE_FORMULA);
create index FG_CHEM_DOC_SEARCH_HX on FG_CHEM_DOC_SEARCH (CD_HASH);
create index FG_CHEM_DOC_SEARCH_PX on FG_CHEM_DOC_SEARCH (CD_PRE_CALCULATED);
create index FG_CHEM_DOC_SEARCH_THX on FG_CHEM_DOC_SEARCH (CD_TAUT_HASH);

prompt
prompt Creating table FG_CHEM_DOC_SEARCH_UL
prompt ====================================
prompt
create table FG_CHEM_DOC_SEARCH_UL
(
  update_id   NUMBER(10) not null,
  update_info VARCHAR2(120) not null,
  cache_id    VARCHAR2(32) not null
)
;
alter table FG_CHEM_DOC_SEARCH_UL
  add primary key (UPDATE_ID);
create index FG_CHEM_DOC_SEARCH_CX on FG_CHEM_DOC_SEARCH_UL (CACHE_ID);

prompt
prompt Creating table FG_CHEM_DOODLE_DATA
prompt ==================================
prompt
create table FG_CHEM_DOODLE_DATA
(
  parent_id              VARCHAR2(200) not null,
  mol_data               VARCHAR2(4000),
  smiles_data            VARCHAR2(4000),
  mol_attr               VARCHAR2(200),
  mol_type               VARCHAR2(1),
  mol_order              NUMBER,
  mol_img_url            VARCHAR2(500),
  inchi_data             VARCHAR2(4000),
  reaction_all_data      CLOB,
  mol_img_file_id        VARCHAR2(500),
  full_img_file_id       VARCHAR2(500),
  reaction_all_data_link VARCHAR2(100),
  mol_cml                VARCHAR2(100)
)
;

prompt
prompt Creating table FG_CHEM_SEARCH
prompt =============================
prompt
create table FG_CHEM_SEARCH
(
  cd_id                NUMBER(10) not null,
  cd_structure         BLOB not null,
  cd_smiles            VARCHAR2(4000),
  cd_formula           VARCHAR2(100),
  cd_sortable_formula  VARCHAR2(500),
  cd_molweight         FLOAT,
  cd_hash              NUMBER(10) not null,
  cd_flags             VARCHAR2(20),
  cd_timestamp         DATE not null,
  cd_pre_calculated    NUMBER(1) default 0 not null,
  cd_taut_hash         NUMBER(10) not null,
  cd_taut_frag_hash    VARCHAR2(4000),
  cd_screen_descriptor VARCHAR2(4000),
  cd_fp1               NUMBER(10) not null,
  cd_fp2               NUMBER(10) not null,
  cd_fp3               NUMBER(10) not null,
  cd_fp4               NUMBER(10) not null,
  cd_fp5               NUMBER(10) not null,
  cd_fp6               NUMBER(10) not null,
  cd_fp7               NUMBER(10) not null,
  cd_fp8               NUMBER(10) not null,
  cd_fp9               NUMBER(10) not null,
  cd_fp10              NUMBER(10) not null,
  cd_fp11              NUMBER(10) not null,
  cd_fp12              NUMBER(10) not null,
  cd_fp13              NUMBER(10) not null,
  cd_fp14              NUMBER(10) not null,
  cd_fp15              NUMBER(10) not null,
  cd_fp16              NUMBER(10) not null,
  formid               VARCHAR2(100),
  fullformcode         VARCHAR2(100),
  moltype              VARCHAR2(100),
  elementid            VARCHAR2(100)
)
;
alter table FG_CHEM_SEARCH
  add primary key (CD_ID);
create index FG_CHEM_SEARCH_FX on FG_CHEM_SEARCH (CD_SORTABLE_FORMULA);
create index FG_CHEM_SEARCH_HX on FG_CHEM_SEARCH (CD_HASH);
create index FG_CHEM_SEARCH_PX on FG_CHEM_SEARCH (CD_PRE_CALCULATED);
create index FG_CHEM_SEARCH_THX on FG_CHEM_SEARCH (CD_TAUT_HASH);

prompt
prompt Creating table FG_CHEM_SEARCH_UL
prompt ================================
prompt
create table FG_CHEM_SEARCH_UL
(
  update_id   NUMBER(10) not null,
  update_info VARCHAR2(120) not null,
  cache_id    VARCHAR2(32) not null
)
;
alter table FG_CHEM_SEARCH_UL
  add primary key (UPDATE_ID);
create index FG_CHEM_SEARCH_CX on FG_CHEM_SEARCH_UL (CACHE_ID);

prompt
prompt Creating table FG_CLOB_FILES
prompt ============================
prompt
create table FG_CLOB_FILES
(
  file_id           VARCHAR2(200) not null,
  file_name         VARCHAR2(500),
  file_content      CLOB,
  content_type      VARCHAR2(500),
  reference_element VARCHAR2(200)
)
;
create unique index IDX_CLOB_FILES on FG_CLOB_FILES (FILE_ID);

prompt
prompt Creating table FG_DEBUG
prompt =======================
prompt
create table FG_DEBUG
(
  comments     CLOB,
  commenttime  DATE default sysdate,
  comment_info VARCHAR2(1000)
)
;

prompt
prompt Creating table FG_DIAGRAM
prompt =========================
prompt
create table FG_DIAGRAM
(
  element_id   VARCHAR2(200) not null,
  element_name VARCHAR2(500),
  content      CLOB,
  content_type VARCHAR2(500),
  image_id     VARCHAR2(200)
)
;
comment on column FG_DIAGRAM.image_id
  is 'a pointer to the fg_files table';

prompt
prompt Creating table FG_DYNAMICPARAMS
prompt ===============================
prompt
create table FG_DYNAMICPARAMS
(
  id        NUMBER,
  order_    NUMBER,
  label     VARCHAR2(500),
  parent_id VARCHAR2(500),
  active    VARCHAR2(500)
)
;

prompt
prompt Creating table FG_EXCEL_USER_TEMP_DATA
prompt ======================================
prompt
create table FG_EXCEL_USER_TEMP_DATA
(
  formid    VARCHAR2(500),
  timestamp DATE,
  user_id   VARCHAR2(500),
  domid     VARCHAR2(500),
  value     CLOB
)
;

prompt
prompt Creating table FG_FAVORITE
prompt ==========================
prompt
create table FG_FAVORITE
(
  object_id  VARCHAR2(100) not null,
  creator_id VARCHAR2(100) not null
)
;

prompt
prompt Creating table FG_FILES
prompt =======================
prompt
create table FG_FILES
(
  file_id         VARCHAR2(200) not null,
  file_name       VARCHAR2(500),
  file_content    BLOB,
  content_type    VARCHAR2(500),
  reference_form  VARCHAR2(100),
  timestamp       DATE default sysdate,
  tmp_file        NUMBER default 0,
  file_display_id VARCHAR2(200),
  file_chem_id    VARCHAR2(200)
)
;
comment on column FG_FILES.reference_form
  is 'form that used to attach current image';
comment on column FG_FILES.timestamp
  is 'creation date';
comment on column FG_FILES.file_display_id
  is 'related file_id for preview';
comment on column FG_FILES.file_chem_id
  is 'related to FG_CHEM_DOC_SEARCH id';
create unique index IDX_FILES on FG_FILES (FILE_ID);

prompt
prompt Creating table FG_FILES_SRC
prompt ===========================
prompt
create table FG_FILES_SRC
(
  file_id      VARCHAR2(200) not null,
  file_name    VARCHAR2(500),
  file_content BLOB,
  content_type VARCHAR2(500),
  timestamp    DATE,
  parentid     VARCHAR2(200),
  cd_smiles    VARCHAR2(4000)
)
;

prompt
prompt Creating table FG_FORM
prompt ======================
prompt
create table FG_FORM
(
  id              NUMBER,
  formcode        VARCHAR2(100),
  description     VARCHAR2(4000),
  active          VARCHAR2(100),
  form_type       VARCHAR2(100),
  title           VARCHAR2(100),
  subtitle        VARCHAR2(500),
  use_as_template NUMBER default 0,
  group_name      VARCHAR2(100),
  numberoforder   NUMBER default 0,
  formcode_entity VARCHAR2(100),
  ignore_nav      VARCHAR2(100) default 0,
  usecache        VARCHAR2(100) default 0,
  change_date     DATE default SYSDATE
)
;
comment on column FG_FORM.form_type
  is 'result / report';
comment on column FG_FORM.use_as_template
  is 'one template per formtype';
comment on column FG_FORM.formcode_entity
  is 'the form code we save in the DB => FORMCODE is define the display, FORMCODE_ENTITY define the real entity';
comment on column FG_FORM.ignore_nav
  is 'ignore navigation (prevent push into the session stack)';
alter table FG_FORM
  add constraint FORMCODEUNIQUE unique (FORMCODE);
create unique index FORMCODE_INSENSITIVE_UNIQUE on FG_FORM (UPPER(FORMCODE));

prompt
prompt Creating table FG_FORMADDITIONALDATA
prompt ====================================
prompt
create table FG_FORMADDITIONALDATA
(
  id            NUMBER,
  parentid      VARCHAR2(500) default -1,
  entityimpcode VARCHAR2(500),
  value         VARCHAR2(500),
  config_id     VARCHAR2(500),
  formcode      VARCHAR2(500),
  info          VARCHAR2(500)
)
;

prompt
prompt Creating table FG_FORMADDITIONALDATA_HST
prompt ========================================
prompt
create table FG_FORMADDITIONALDATA_HST
(
  id            NUMBER,
  parentid      VARCHAR2(500),
  entityimpcode VARCHAR2(500),
  value         VARCHAR2(500),
  config_id     VARCHAR2(500),
  formcode      VARCHAR2(500),
  info          VARCHAR2(500),
  change_date   DATE
)
;

prompt
prompt Creating table FG_FORMELEMENTINFOATMETA_TMP
prompt ===========================================
prompt
create table FG_FORMELEMENTINFOATMETA_TMP
(
  formcode            VARCHAR2(100),
  entityimpcode       VARCHAR2(100),
  elementclass        VARCHAR2(100),
  displaylabel        VARCHAR2(500),
  isparentpathid      NUMBER(1),
  additionaldata      NUMBER(1),
  ishidden            NUMBER(1),
  issearchidholder    NUMBER(1),
  formcodeentitylabel VARCHAR2(100),
  formcodetyplabel    VARCHAR2(100),
  islistid            NUMBER(1),
  issearchelement     NUMBER(1),
  datatype            VARCHAR2(100),
  datatype_info       VARCHAR2(100)
)
;
comment on column FG_FORMELEMENTINFOATMETA_TMP.displaylabel
  is 'the entityimpcode label - taken from the formentity label configuration';
comment on column FG_FORMELEMENTINFOATMETA_TMP.issearchidholder
  is 'form builder config for non id elements holding an ID (for example when we put in text element id and we not using ddl because of very long lists)';
comment on column FG_FORMELEMENTINFOATMETA_TMP.formcodeentitylabel
  is 'form code entity namr taken from the lables [taken from the form.properties file]';
comment on column FG_FORMELEMENTINFOATMETA_TMP.formcodetyplabel
  is 'from code type for the forms that are mapped to different forms (like the formcode ExperimentAn which mapped to Experiment and the type is Analyitical)  [taken from the form.properties label file]';
comment on column FG_FORMELEMENTINFOATMETA_TMP.issearchelement
  is '1 - should be include in search screen , 0 - not include Note: the place we config it is in the class ElementInfoAuditTrailMeta';

prompt
prompt Creating table FG_FORMENTITY
prompt ============================
prompt
create table FG_FORMENTITY
(
  id             NUMBER not null,
  formcode       VARCHAR2(100) not null,
  numberoforder  NUMBER not null,
  entitytype     VARCHAR2(100) not null,
  entityimpcode  VARCHAR2(100) not null,
  entityimpclass VARCHAR2(100) not null,
  entityimpinit  VARCHAR2(4000) not null,
  comments       VARCHAR2(4000),
  fs             VARCHAR2(4000),
  fs_gap         VARCHAR2(4000),
  change_date    DATE default sysdate
)
;
comment on column FG_FORMENTITY.comments
  is 'developer / form builder user comment';
comment on column FG_FORMENTITY.fs
  is 'FS requirement';
comment on column FG_FORMENTITY.fs_gap
  is 'empty when no gap between FS requirement and the implementation';
alter table FG_FORMENTITY
  add constraint PK_FG_FORMENTITY primary key (ID);
alter table FG_FORMENTITY
  add constraint UK_FG_FORMENTITY unique (ENTITYIMPCODE, FORMCODE);
create unique index FORMENTITY_INSENSITIVE_UNIQUE on FG_FORMENTITY (UPPER(FORMCODE), UPPER(ENTITYIMPCODE));

prompt
prompt Creating table FG_FORMENTITY_HST
prompt ================================
prompt
create table FG_FORMENTITY_HST
(
  id             NUMBER not null,
  formcode       VARCHAR2(100) not null,
  numberoforder  NUMBER not null,
  entitytype     VARCHAR2(100) not null,
  entityimpcode  VARCHAR2(100) not null,
  entityimpclass VARCHAR2(100) not null,
  entityimpinit  VARCHAR2(4000) not null,
  comments       VARCHAR2(4000),
  fs             VARCHAR2(4000),
  fs_gap         VARCHAR2(4000),
  change_date    DATE,
  change_by      NUMBER default -1,
  change_type    VARCHAR2(1)
)
;
comment on column FG_FORMENTITY_HST.change_type
  is 'I/U';

prompt
prompt Creating table FG_FORMENTITY_INVALID
prompt ====================================
prompt
create table FG_FORMENTITY_INVALID
(
  id NUMBER not null
)
;

prompt
prompt Creating table FG_FORMID_UNPIVOT_LIST_TMP
prompt =========================================
prompt
create table FG_FORMID_UNPIVOT_LIST_TMP
(
  id   NUMBER,
  flag NUMBER
)
;
comment on column FG_FORMID_UNPIVOT_LIST_TMP.flag
  is '0';

prompt
prompt Creating table FG_FORMLASTSAVEVALUE
prompt ===================================
prompt
create table FG_FORMLASTSAVEVALUE
(
  id              NUMBER,
  formid          VARCHAR2(100) not null,
  formcode_entity VARCHAR2(100) not null,
  entityimpcode   VARCHAR2(100) not null,
  userid          VARCHAR2(100) not null,
  sessionid       VARCHAR2(500),
  active          NUMBER(1),
  formidscript    VARCHAR2(100),
  formcode_name   VARCHAR2(100),
  created_by      VARCHAR2(100),
  creation_date   DATE default sysdate,
  timestamp       DATE default sysdate,
  change_by       VARCHAR2(100),
  save_name_id    NUMBER default -1,
  login_sessionid VARCHAR2(500),
  entityimpvalue  CLOB
)
;
comment on column FG_FORMLASTSAVEVALUE.timestamp
  is 'CHANGE DATE';
comment on column FG_FORMLASTSAVEVALUE.save_name_id
  is 'reference fg_formlastsavevalue_name.save_name';

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_HST
prompt =======================================
prompt
create table FG_FORMLASTSAVEVALUE_HST
(
  id                 NUMBER,
  formid             VARCHAR2(100),
  formcode_entity    VARCHAR2(100),
  entityimpcode      VARCHAR2(100),
  entityimpvalue     VARCHAR2(4000),
  userid             VARCHAR2(100),
  change_comment     VARCHAR2(500),
  change_id          NUMBER,
  change_by          NUMBER,
  change_type        VARCHAR2(1),
  change_date        DATE,
  sessionid          VARCHAR2(500),
  active             NUMBER(1),
  displayvalue       VARCHAR2(4000),
  updatejobflag      VARCHAR2(10),
  displaylabel       VARCHAR2(500),
  path_id            VARCHAR2(100),
  is_file            NUMBER(1) default 0,
  is_idlist          NUMBER(1) default 0,
  db_transaction_id  VARCHAR2(500),
  tmp_entityimpvalue VARCHAR2(4000),
  tmp_displayvalue   VARCHAR2(4000)
)
;
comment on column FG_FORMLASTSAVEVALUE_HST.active
  is '1';
comment on column FG_FORMLASTSAVEVALUE_HST.path_id
  is 'ref and doc (pop up) get the parentId';
comment on column FG_FORMLASTSAVEVALUE_HST.is_file
  is '1 the value is link to fg_files else 0';

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_INF
prompt =======================================
prompt
create table FG_FORMLASTSAVEVALUE_INF
(
  id                 NUMBER,
  formid             VARCHAR2(100),
  formcode_entity    VARCHAR2(100),
  entityimpcode      VARCHAR2(100),
  entityimpvalue     VARCHAR2(4000),
  userid             VARCHAR2(100),
  change_comment     VARCHAR2(500),
  change_id          NUMBER,
  change_by          NUMBER,
  change_type        VARCHAR2(1),
  change_date        DATE,
  sessionid          VARCHAR2(500),
  active             NUMBER(1),
  displayvalue       VARCHAR2(4000),
  updatejobflag      VARCHAR2(10),
  displaylabel       VARCHAR2(500),
  path_id            VARCHAR2(100),
  is_file            NUMBER(1) default 0,
  is_idlist          NUMBER(1) default 0,
  db_transaction_id  VARCHAR2(500),
  tmp_entityimpvalue VARCHAR2(4000),
  tmp_displayvalue   VARCHAR2(4000)
)
;
comment on column FG_FORMLASTSAVEVALUE_INF.updatejobflag
  is '0 - OK, 1 - need display correction, 2 - error';
comment on column FG_FORMLASTSAVEVALUE_INF.path_id
  is 'ref and doc (pop up) get the parentId null in struct';
comment on column FG_FORMLASTSAVEVALUE_INF.is_file
  is '1 the value is link to fg_files else 0';

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_INF_GTMP
prompt ============================================
prompt
create global temporary table FG_FORMLASTSAVEVALUE_INF_GTMP
(
  id                 NUMBER,
  formid             VARCHAR2(100),
  formcode_entity    VARCHAR2(100),
  entityimpcode      VARCHAR2(100),
  entityimpvalue     VARCHAR2(4000),
  userid             VARCHAR2(100),
  change_comment     VARCHAR2(500),
  change_id          NUMBER,
  change_by          NUMBER,
  change_type        VARCHAR2(1),
  change_date        DATE,
  sessionid          VARCHAR2(500),
  active             NUMBER(1),
  displayvalue       VARCHAR2(4000),
  updatejobflag      VARCHAR2(10),
  displaylabel       VARCHAR2(500),
  path_id            VARCHAR2(100),
  is_file            NUMBER(1),
  is_idlist          NUMBER(1),
  db_transaction_id  VARCHAR2(500),
  tmp_entityimpvalue VARCHAR2(4000),
  tmp_displayvalue   VARCHAR2(4000)
)
on commit preserve rows;

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_INF_IDTMP
prompt =============================================
prompt
create table FG_FORMLASTSAVEVALUE_INF_IDTMP
(
  id                 NUMBER,
  formid             VARCHAR2(100),
  formcode_entity    VARCHAR2(100),
  entityimpcode      VARCHAR2(100),
  entityimpvalue     VARCHAR2(4000),
  userid             VARCHAR2(100),
  change_comment     VARCHAR2(500),
  change_id          NUMBER,
  change_by          NUMBER,
  change_type        VARCHAR2(1),
  change_date        DATE,
  sessionid          VARCHAR2(500),
  active             NUMBER(1),
  displayvalue       VARCHAR2(4000),
  updatejobflag      VARCHAR2(10),
  displaylabel       VARCHAR2(500),
  path_id            VARCHAR2(100),
  is_file            NUMBER(1),
  is_idlist          NUMBER(1),
  db_transaction_id  VARCHAR2(500),
  tmp_entityimpvalue VARCHAR2(4000),
  tmp_displayvalue   VARCHAR2(4000)
)
;

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_INF_RT
prompt ==========================================
prompt
create table FG_FORMLASTSAVEVALUE_INF_RT
(
  id      NUMBER,
  rt_text VARCHAR2(4000)
)
;

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_INF_SS
prompt ==========================================
prompt
create table FG_FORMLASTSAVEVALUE_INF_SS
(
  id                 NUMBER,
  formid             VARCHAR2(100),
  formcode_entity    VARCHAR2(100),
  entityimpcode      VARCHAR2(100),
  entityimpvalue     VARCHAR2(4000),
  userid             VARCHAR2(100),
  change_comment     VARCHAR2(500),
  change_id          NUMBER,
  change_by          NUMBER,
  change_type        VARCHAR2(1),
  change_date        DATE,
  sessionid          VARCHAR2(500),
  active             NUMBER(1),
  displayvalue       VARCHAR2(4000),
  updatejobflag      VARCHAR2(10),
  displaylabel       VARCHAR2(500),
  path_id            VARCHAR2(100),
  is_file            NUMBER(1),
  is_idlist          NUMBER(1),
  db_transaction_id  VARCHAR2(500),
  tmp_entityimpvalue VARCHAR2(4000),
  tmp_displayvalue   VARCHAR2(4000),
  experiment_id      VARCHAR2(100),
  log_date           DATE,
  log_version        VARCHAR2(100)
)
;

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_INF_SSM
prompt ===========================================
prompt
create table FG_FORMLASTSAVEVALUE_INF_SSM
(
  formid        VARCHAR2(100),
  formid_ref    VARCHAR2(100),
  change_date   DATE,
  change_by     NUMBER,
  comments      VARCHAR2(500),
  snapshot_type VARCHAR2(100)
)
;

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_INF_SST
prompt ===========================================
prompt
create global temporary table FG_FORMLASTSAVEVALUE_INF_SST
(
  formid             VARCHAR2(100),
  change_date        DATE,
  change_by          NUMBER,
  formcode_entity    VARCHAR2(100),
  userid             VARCHAR2(100),
  id                 NUMBER,
  entityimpcode      VARCHAR2(100),
  entityimpvalue     VARCHAR2(4000),
  change_comment     VARCHAR2(500),
  change_id          NUMBER,
  change_type        VARCHAR2(1),
  sessionid          VARCHAR2(500),
  active             NUMBER(1),
  displayvalue       VARCHAR2(4000),
  updatejobflag      VARCHAR2(10),
  displaylabel       VARCHAR2(500),
  path_id            VARCHAR2(100),
  is_file            NUMBER(1),
  is_idlist          NUMBER(1),
  db_transaction_id  VARCHAR2(500),
  tmp_entityimpvalue VARCHAR2(4000),
  tmp_displayvalue   VARCHAR2(4000)
)
on commit preserve rows;

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_INF_SSTMP
prompt =============================================
prompt
create table FG_FORMLASTSAVEVALUE_INF_SSTMP
(
  id                 NUMBER,
  formid             VARCHAR2(100),
  formcode_entity    VARCHAR2(100),
  entityimpcode      VARCHAR2(100),
  entityimpvalue     VARCHAR2(4000),
  userid             VARCHAR2(100),
  change_comment     VARCHAR2(500),
  change_id          NUMBER,
  change_by          NUMBER,
  change_type        VARCHAR2(1),
  change_date        DATE,
  sessionid          VARCHAR2(500),
  active             NUMBER(1),
  displayvalue       VARCHAR2(4000),
  updatejobflag      VARCHAR2(10),
  displaylabel       VARCHAR2(500),
  path_id            VARCHAR2(100),
  is_file            NUMBER(1),
  is_idlist          NUMBER(1),
  db_transaction_id  VARCHAR2(500),
  tmp_entityimpvalue VARCHAR2(4000),
  tmp_displayvalue   VARCHAR2(4000),
  experiment_id      VARCHAR2(100),
  log_date           DATE,
  log_version        VARCHAR2(100)
)
;

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_INF_SS_BU
prompt =============================================
prompt
create table FG_FORMLASTSAVEVALUE_INF_SS_BU
(
  id                 NUMBER,
  formid             VARCHAR2(100),
  formcode_entity    VARCHAR2(100),
  entityimpcode      VARCHAR2(100),
  entityimpvalue     VARCHAR2(4000),
  userid             VARCHAR2(100),
  change_comment     VARCHAR2(500),
  change_id          NUMBER,
  change_by          NUMBER,
  change_type        VARCHAR2(1),
  change_date        DATE,
  sessionid          VARCHAR2(500),
  active             NUMBER(1),
  displayvalue       VARCHAR2(4000),
  updatejobflag      VARCHAR2(10),
  displaylabel       VARCHAR2(500),
  path_id            VARCHAR2(100),
  is_file            NUMBER(1),
  is_idlist          NUMBER(1),
  db_transaction_id  VARCHAR2(500),
  tmp_entityimpvalue VARCHAR2(4000),
  tmp_displayvalue   VARCHAR2(4000)
)
;

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_NAME
prompt ========================================
prompt
create table FG_FORMLASTSAVEVALUE_NAME
(
  save_name_id     NUMBER,
  formcode_name    VARCHAR2(100),
  save_name        VARCHAR2(100),
  save_description VARCHAR2(100),
  active           NUMBER(1),
  userid           VARCHAR2(100) not null,
  created_by       VARCHAR2(100),
  creation_date    DATE default sysdate,
  timestamp        DATE
)
;

prompt
prompt Creating table FG_FORMLASTSAVEVALUE_UNPIVOT
prompt ===========================================
prompt
create table FG_FORMLASTSAVEVALUE_UNPIVOT
(
  id              NUMBER,
  formid          VARCHAR2(100) not null,
  formcode_entity VARCHAR2(100) not null,
  entityimpcode   VARCHAR2(100) not null,
  userid          VARCHAR2(100) not null,
  sessionid       VARCHAR2(500),
  active          NUMBER(1),
  formidscript    VARCHAR2(100),
  formcode_name   VARCHAR2(100),
  created_by      VARCHAR2(100),
  creation_date   DATE,
  timestamp       DATE,
  change_by       VARCHAR2(100),
  save_name_id    NUMBER,
  login_sessionid VARCHAR2(500),
  entityimpvalue  VARCHAR2(4000),
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100)
)
;

prompt
prompt Creating table FG_FORMLASTSAVE_TRANSACT_FAIL
prompt ============================================
prompt
create table FG_FORMLASTSAVE_TRANSACT_FAIL
(
  transaction_failure_number VARCHAR2(200),
  delete_flag                NUMBER(1) default 0,
  insertdate                 DATE default SYSDATE
)
;

prompt
prompt Creating table FG_FORMMONITOPARAM_DATA
prompt ======================================
prompt
create table FG_FORMMONITOPARAM_DATA
(
  parent_id      VARCHAR2(500),
  value          VARCHAR2(500),
  uom_id         VARCHAR2(500),
  config_id      VARCHAR2(500),
  name           VARCHAR2(500),
  json_source    CLOB,
  calcidentifier VARCHAR2(500)
)
;
comment on column FG_FORMMONITOPARAM_DATA.parent_id
  is 'refer FG_S_PARAMMONITORING_PIVOT.PARAMMONITORING_ID (formid)';

prompt
prompt Creating table FG_FORMTEST_DATA
prompt ===============================
prompt
create table FG_FORMTEST_DATA
(
  parent_id NUMBER,
  value     VARCHAR2(500),
  uom_id    VARCHAR2(100),
  config_id NUMBER
)
;
comment on column FG_FORMTEST_DATA.parent_id
  is 'formid NOTE: NOT ELEMENT ID -> THE ELEMENT IS NOT SAVE ON THE DB. WE DISPLAY ACCORDING TO THE TEMPLATE AND ON UPDATE WE MTACH ACCORDING THIS TABLE VALUES';
comment on column FG_FORMTEST_DATA.config_id
  is 'test_config';

prompt
prompt Creating table FG_FORM_CHANGE_LIST
prompt ==================================
prompt
create table FG_FORM_CHANGE_LIST
(
  formcode    VARCHAR2(100),
  update_flag NUMBER(1) default 0
)
;

prompt
prompt Creating table FG_FORM_HST
prompt ==========================
prompt
create table FG_FORM_HST
(
  id              NUMBER,
  formcode        VARCHAR2(100),
  description     VARCHAR2(4000),
  active          VARCHAR2(100),
  form_type       VARCHAR2(100),
  title           VARCHAR2(100),
  subtitle        VARCHAR2(500),
  use_as_template NUMBER,
  group_name      VARCHAR2(100),
  numberoforder   NUMBER,
  formcode_entity VARCHAR2(100),
  ignore_nav      VARCHAR2(100),
  usecache        VARCHAR2(100),
  change_date     DATE,
  change_by       NUMBER default -1,
  change_type     VARCHAR2(1)
)
;
comment on column FG_FORM_HST.change_type
  is 'I/U';

prompt
prompt Creating table FG_HISTORICAL_SPREAD_DATA
prompt ========================================
prompt
create table FG_HISTORICAL_SPREAD_DATA
(
  formid         VARCHAR2(100) not null,
  timestamp      DATE,
  user_id        VARCHAR2(100),
  active         NUMBER,
  formcode       VARCHAR2(100),
  spreadsheet_id VARCHAR2(500)
)
;

prompt
prompt Creating table FG_I_CHEM_DATA_V_B
prompt =================================
prompt
create table FG_I_CHEM_DATA_V_B
(
  clobcontent CLOB
)
;

prompt
prompt Creating table FG_I_UNITTEST_GLOBAL_SAVE_V_SS
prompt =============================================
prompt
create table FG_I_UNITTEST_GLOBAL_SAVE_V_SS
(
  parent_id       VARCHAR2(100),
  formcode        VARCHAR2(100),
  form_id         VARCHAR2(100),
  userid          CHAR(2),
  parent_formcode VARCHAR2(100),
  tabletype       VARCHAR2(400)
)
;

prompt
prompt Creating table FG_I_WEBIX_OUTPUT_ALL_V_SS
prompt =========================================
prompt
create table FG_I_WEBIX_OUTPUT_ALL_V_SS
(
  material_id   VARCHAR2(4000),
  result_id     VARCHAR2(100),
  experiment_id VARCHAR2(4000),
  step_id       VARCHAR2(4000),
  batch_id      VARCHAR2(4000),
  mass          VARCHAR2(100),
  result_value  VARCHAR2(500),
  isstandart    VARCHAR2(500),
  result_uom_id VARCHAR2(500)
)
;

prompt
prompt Creating table FG_JCEHM_BU
prompt ==========================
prompt
create table FG_JCEHM_BU
(
  cd_id                NUMBER(10) not null,
  cd_structure         BLOB not null,
  cd_smiles            VARCHAR2(4000),
  cd_formula           VARCHAR2(100),
  cd_sortable_formula  VARCHAR2(500),
  cd_molweight         FLOAT,
  cd_hash              NUMBER(10) not null,
  cd_flags             VARCHAR2(20),
  cd_timestamp         DATE not null,
  cd_pre_calculated    NUMBER(1) not null,
  cd_taut_hash         NUMBER(10) not null,
  cd_taut_frag_hash    VARCHAR2(4000),
  cd_screen_descriptor VARCHAR2(4000),
  cd_fp1               NUMBER(10) not null,
  cd_fp2               NUMBER(10) not null,
  cd_fp3               NUMBER(10) not null,
  cd_fp4               NUMBER(10) not null,
  cd_fp5               NUMBER(10) not null,
  cd_fp6               NUMBER(10) not null,
  cd_fp7               NUMBER(10) not null,
  cd_fp8               NUMBER(10) not null,
  cd_fp9               NUMBER(10) not null,
  cd_fp10              NUMBER(10) not null,
  cd_fp11              NUMBER(10) not null,
  cd_fp12              NUMBER(10) not null,
  cd_fp13              NUMBER(10) not null,
  cd_fp14              NUMBER(10) not null,
  cd_fp15              NUMBER(10) not null,
  cd_fp16              NUMBER(10) not null,
  formid               VARCHAR2(100),
  fullformcode         VARCHAR2(100),
  moltype              VARCHAR2(100),
  elementid            VARCHAR2(100)
)
;

prompt
prompt Creating table FG_NOTIFICATION_COMPARE
prompt ======================================
prompt
create table FG_NOTIFICATION_COMPARE
(
  d_notification_message_id     VARCHAR2(40),
  notification_module_id        VARCHAR2(40),
  message_type_id               VARCHAR2(40),
  description                   VARCHAR2(2000 CHAR),
  trigger_type_id               VARCHAR2(40),
  on_save_formcode              VARCHAR2(50),
  email_subject                 VARCHAR2(4000 CHAR),
  email_body                    VARCHAR2(4000),
  scheduler_interval            VARCHAR2(40),
  where_statement               VARCHAR2(4000),
  resend                        VARCHAR2(40),
  p_notification_module_type_id VARCHAR2(40),
  module_name                   VARCHAR2(200 CHAR),
  select_statement              VARCHAR2(4000),
  msguniqueidname               VARCHAR2(1000 CHAR),
  order_by                      VARCHAR2(4000),
  addressee_type_id             VARCHAR2(40),
  send_type                     VARCHAR2(10),
  addressee_user_id             VARCHAR2(40),
  params_field_names            VARCHAR2(4000),
  addressee_group_select        VARCHAR2(4000),
  add_attachments               VARCHAR2(40),
  attached_report_name          VARCHAR2(1000 CHAR),
  attached_report_type          VARCHAR2(1000 CHAR),
  isactive                      VARCHAR2(40)
)
;

prompt
prompt Creating table FG_P_EXPREPORT_DATA_TMP
prompt ======================================
prompt
create table FG_P_EXPREPORT_DATA_TMP
(
  experiment_id     VARCHAR2(500),
  order_            NUMBER,
  step_id           VARCHAR2(500),
  materialref_id    VARCHAR2(500),
  tabletype         VARCHAR2(500),
  result_id         VARCHAR2(500),
  result_smartpivot VARCHAR2(4000),
  formnumberid      VARCHAR2(500),
  statekey          VARCHAR2(500),
  order2            VARCHAR2(500),
  row_timestamp     DATE default sysdate
)
;

prompt
prompt Creating table FG_P_EXPREPORT_SAMPLE_TMP
prompt ========================================
prompt
create table FG_P_EXPREPORT_SAMPLE_TMP
(
  statekey       VARCHAR2(500),
  sample_id      NUMBER,
  samplename     VARCHAR2(500),
  sampledesc     VARCHAR2(500),
  commentsforcoa VARCHAR2(500),
  experiment_id  VARCHAR2(500),
  creator_id     VARCHAR2(500),
  ammount        VARCHAR2(500),
  row_timestamp  DATE default sysdate
)
;

prompt
prompt Creating table FG_REPORTDESIGN
prompt ==============================
prompt
create table FG_REPORTDESIGN
(
  formcode           VARCHAR2(100) default 'ReportDesign' not null,
  created_by         VARCHAR2(100),
  creation_date      DATE,
  timestamp          DATE default sysdate,
  reportdesign_value CLOB,
  reportdesign_name  VARCHAR2(100)
)
;

prompt
prompt Creating table FG_REPORT_LIST
prompt =============================
prompt
create table FG_REPORT_LIST
(
  id                 VARCHAR2(100),
  report_category    VARCHAR2(100),
  report_sql         VARCHAR2(1000),
  report_description VARCHAR2(1000),
  change_by          VARCHAR2(100),
  active             NUMBER,
  timestamp          DATE,
  report_user_id     NUMBER,
  report_scope       VARCHAR2(100),
  report_style       VARCHAR2(100),
  report_name        VARCHAR2(500) not null,
  report_save_data   VARCHAR2(4000),
  meta_data          VARCHAR2(4000),
  system_row         NUMBER default 0
)
;
comment on column FG_REPORT_LIST.report_sql
  is 'fg_report_<catalog>_v';
comment on column FG_REPORT_LIST.report_scope
  is 'public / private';
comment on column FG_REPORT_LIST.report_style
  is 'simple (query builder) / custom ';
comment on column FG_REPORT_LIST.report_name
  is 'save as or save in private / save for public';
comment on column FG_REPORT_LIST.meta_data
  is 'meta data JSON using: fg_report_<catalog>_md_v, fg_report_<catalog>_col_v, fg_report_<catalog>_grp_v - NOT SAVE IN THE DB';
comment on column FG_REPORT_LIST.system_row
  is '1 - rows enterd by the system and should not be deleted';
create unique index REPORT_NAME_UNIQUE on FG_REPORT_LIST (REPORT_NAME);

prompt
prompt Creating table FG_REPORT_LIST_BU2
prompt =================================
prompt
create table FG_REPORT_LIST_BU2
(
  id                 VARCHAR2(100),
  report_category    VARCHAR2(100),
  report_sql         VARCHAR2(1000),
  report_description VARCHAR2(1000),
  change_by          VARCHAR2(100),
  active             NUMBER,
  timestamp          DATE,
  report_user_id     NUMBER,
  report_scope       VARCHAR2(100),
  report_style       VARCHAR2(100),
  report_name        VARCHAR2(500) not null,
  report_save_data   VARCHAR2(4000),
  meta_data          VARCHAR2(4000),
  system_row         NUMBER
)
;

prompt
prompt Creating table FG_RESOURCE
prompt ==========================
prompt
create table FG_RESOURCE
(
  id    NUMBER,
  type  VARCHAR2(100),
  code  VARCHAR2(100),
  value VARCHAR2(1200),
  info  VARCHAR2(1000)
)
;
comment on column FG_RESOURCE.info
  is 'TODO DESC';
alter table FG_RESOURCE
  add constraint KU_RESOURCE unique (CODE, TYPE);

prompt
prompt Creating table FG_RESULTS
prompt =========================
prompt
create table FG_RESULTS
(
  result_id           VARCHAR2(100) not null,
  experiment_id       VARCHAR2(4000),
  result_test_name    VARCHAR2(4000),
  result_name         VARCHAR2(4000),
  sample_id           VARCHAR2(100),
  result_value        VARCHAR2(500),
  result_uom_id       VARCHAR2(500),
  result_type         CHAR(500),
  result_material_id  VARCHAR2(500),
  result_date         DATE,
  result_time         VARCHAR2(8),
  result_comment      VARCHAR2(4000),
  selftest_id         VARCHAR2(4000),
  result_is_active    CHAR(500),
  resultref_id        VARCHAR2(4000),
  result_is_webix     CHAR(500),
  result_materialname VARCHAR2(500),
  result_request_id   VARCHAR2(4000),
  result_change_by    VARCHAR2(100)
)
;
alter table FG_RESULTS
  add constraint PK_RESULTS primary key (RESULT_ID);

prompt
prompt Creating table FG_RESULTS_HST
prompt =============================
prompt
create table FG_RESULTS_HST
(
  result_id           VARCHAR2(100) not null,
  experiment_id       VARCHAR2(4000),
  result_test_name    VARCHAR2(4000),
  result_name         VARCHAR2(4000),
  sample_id           VARCHAR2(100),
  result_value        VARCHAR2(500),
  result_uom_id       VARCHAR2(500),
  result_type         CHAR(500),
  result_material_id  VARCHAR2(500),
  result_date         DATE,
  result_time         VARCHAR2(8),
  result_comment      VARCHAR2(500),
  selftest_id         VARCHAR2(4000),
  result_is_active    CHAR(500),
  resultref_id        VARCHAR2(4000),
  result_is_webix     CHAR(500),
  result_materialname VARCHAR2(500),
  result_request_id   VARCHAR2(4000),
  change_comment      VARCHAR2(500),
  change_id           NUMBER,
  change_by           NUMBER,
  change_type         VARCHAR2(1),
  change_date         DATE,
  result_change_by    VARCHAR2(100)
)
;

prompt
prompt Creating table FG_RICHTEXT
prompt ==========================
prompt
create table FG_RICHTEXT
(
  file_id                     VARCHAR2(200) not null,
  file_name                   VARCHAR2(500),
  file_content                CLOB,
  content_type                VARCHAR2(500),
  file_content_text           CLOB,
  file_content_text_no_tables CLOB,
  job_flag                    NUMBER default 0
)
;
create unique index FG_RICHTEXT on FG_RICHTEXT (FILE_ID);

prompt
prompt Creating table FG_R_MATERIALIZED_VIEW
prompt =====================================
prompt
create table FG_R_MATERIALIZED_VIEW
(
  db_name            VARCHAR2(100),
  view_name          VARCHAR2(100),
  view_code          CLOB,
  view_snapshot_date VARCHAR2(100)
)
;

prompt
prompt Creating table FG_R_MESSAGES
prompt ============================
prompt
create table FG_R_MESSAGES
(
  message_id     NUMBER not null,
  message_body   CLOB,
  user_id        VARCHAR2(500),
  message_type   VARCHAR2(100),
  formid         VARCHAR2(500),
  time_stamp     DATE,
  changed_by     VARCHAR2(500),
  additionalinfo VARCHAR2(4000)
)
;
comment on column FG_R_MESSAGES.user_id
  is 'user from distribution list';
comment on column FG_R_MESSAGES.changed_by
  is 'user that do current change';
alter table FG_R_MESSAGES
  add primary key (MESSAGE_ID);

prompt
prompt Creating table FG_R_MESSAGES_STATE
prompt ==================================
prompt
create table FG_R_MESSAGES_STATE
(
  message_id   VARCHAR2(500),
  user_id      VARCHAR2(500),
  is_readed    NUMBER(1) default 0,
  is_deleted   NUMBER(1) default 0,
  updated_by   VARCHAR2(500),
  updated_date DATE
)
;
comment on column FG_R_MESSAGES_STATE.user_id
  is 'user that received current message';

prompt
prompt Creating table FG_R_MESSAGES_STATE_HST
prompt ======================================
prompt
create table FG_R_MESSAGES_STATE_HST
(
  message_id  VARCHAR2(500),
  user_id     VARCHAR2(500),
  is_readed   NUMBER(1),
  is_deleted  NUMBER(1),
  change_id   INTEGER,
  changed_by  VARCHAR2(500),
  change_date DATE,
  change_type VARCHAR2(1)
)
;

prompt
prompt Creating table FG_R_SYSTEM_VIEW
prompt ===============================
prompt
create table FG_R_SYSTEM_VIEW
(
  db_name            VARCHAR2(100),
  view_name          VARCHAR2(100),
  view_code          CLOB,
  view_snapshot_date VARCHAR2(100)
)
;

prompt
prompt Creating table FG_SEQUENCE
prompt ==========================
prompt
create table FG_SEQUENCE
(
  id                    NUMBER not null,
  formcode              VARCHAR2(100),
  insertdate            DATE default sysdate,
  formidname            VARCHAR2(500) default 'NA',
  formpath              VARCHAR2(4000),
  formtabletype         VARCHAR2(400),
  comments              VARCHAR2(100),
  id_holder             NUMBER,
  search_match_id1      NUMBER,
  search_match_id2      NUMBER,
  search_match_id3      NUMBER,
  search_match_id4      NUMBER,
  changedate            DATE default sysdate,
  db_seq_transaction_id VARCHAR2(500),
  tmp_formidname        VARCHAR2(500),
  generate_userid       VARCHAR2(100),
  generate_formid       VARCHAR2(100)
)
;
comment on column FG_SEQUENCE.search_match_id1
  is 'adama-project';
comment on column FG_SEQUENCE.search_match_id2
  is 'adama-subproject';
comment on column FG_SEQUENCE.search_match_id3
  is 'adama-subsubproject';
comment on column FG_SEQUENCE.search_match_id4
  is 'adama-materialId';
comment on column FG_SEQUENCE.generate_userid
  is 'created by ';
comment on column FG_SEQUENCE.generate_formid
  is 'created from (parentid)';
alter table FG_SEQUENCE
  add constraint FG_FORMID_KEY primary key (ID);

prompt
prompt Creating table FG_SEQUENCE_EXCEL
prompt ================================
prompt
create table FG_SEQUENCE_EXCEL
(
  id         NUMBER,
  formcode   VARCHAR2(100),
  insertdate DATE,
  formidname VARCHAR2(400)
)
;

prompt
prompt Creating table FG_SEQUENCE_EXPERIMENT
prompt =====================================
prompt
create table FG_SEQUENCE_EXPERIMENT
(
  id               NUMBER not null,
  formcode         VARCHAR2(100),
  insertdate       DATE,
  formidname       VARCHAR2(400),
  formpath         VARCHAR2(4000),
  formtabletype    VARCHAR2(400),
  comments         VARCHAR2(100),
  id_holder        NUMBER,
  search_match_id1 NUMBER,
  search_match_id2 NUMBER,
  search_match_id3 NUMBER,
  search_match_id4 NUMBER,
  changedate       DATE
)
;

prompt
prompt Creating table FG_SEQUENCE_FILES
prompt ================================
prompt
create table FG_SEQUENCE_FILES
(
  id            NUMBER not null,
  formcode      VARCHAR2(100),
  insertdate    DATE,
  formidname    VARCHAR2(400),
  source_formid VARCHAR2(100)
)
;

prompt
prompt Creating table FG_SEQUENCE_HST
prompt ==============================
prompt
create table FG_SEQUENCE_HST
(
  id               NUMBER not null,
  formcode         VARCHAR2(100),
  insertdate       DATE,
  formidname       VARCHAR2(500),
  formpath         VARCHAR2(4000),
  formtabletype    VARCHAR2(400),
  comments         VARCHAR2(100),
  id_holder        NUMBER,
  search_match_id1 NUMBER,
  search_match_id2 NUMBER,
  search_match_id3 NUMBER,
  search_match_id4 NUMBER,
  changedate       DATE
)
;

prompt
prompt Creating table FG_SEQ_SCRIPT_HOLDER
prompt ===================================
prompt
create table FG_SEQ_SCRIPT_HOLDER
(
  develop_id   NUMBER,
  server_id    NUMBER,
  formcode     VARCHAR2(1000),
  "Time_STAMP" DATE default sysdate
)
;

prompt
prompt Creating table FG_STB_RESULT_SAMPLE
prompt ===================================
prompt
create table FG_STB_RESULT_SAMPLE
(
  sample_id         VARCHAR2(100) not null,
  experstbresult_id VARCHAR2(100) not null,
  resultvalue       VARCHAR2(500),
  resultsign        VARCHAR2(500)
)
;

prompt
prompt Creating table FG_SYS_PARAM
prompt ===========================
prompt
create table FG_SYS_PARAM
(
  retry_count                 NUMBER(2),
  login_timeout               NUMBER,
  password_aging              NUMBER,
  grace_period                NUMBER,
  updated_by                  NUMBER,
  updated_on                  TIMESTAMP(6),
  comments                    VARCHAR2(100),
  is_develop                  NUMBER(1) default 0,
  redirect_notification_email VARCHAR2(100),
  last_build                  DATE,
  last_refresh_mv             DATE,
  last_transaction            DATE,
  transaction_waiting         NUMBER default 0,
  refresh_mv_waiting          NUMBER default 0,
  last_refresh_mv_5min        DATE
)
;
comment on column FG_SYS_PARAM.is_develop
  is '0 develop / 1 production / 2 unittest';
comment on column FG_SYS_PARAM.redirect_notification_email
  is 'send email to this address instead of the user when show "only message" is set to true (1).';
comment on column FG_SYS_PARAM.last_build
  is 'SYSDATE';

prompt
prompt Creating table FG_SYS_SCHED
prompt ===========================
prompt
create table FG_SYS_SCHED
(
  sched_name                VARCHAR2(500),
  start_date                DATE,
  end_date                  DATE,
  comments                  VARCHAR2(4000),
  status                    VARCHAR2(1),
  interval_time             VARCHAR2(500),
  last_end_date             DATE,
  suspend                   NUMBER default 0,
  start_date_success_holder DATE
)
;
comment on column FG_SYS_SCHED.status
  is 'S - SUCCESS, F- FAILURE';
comment on column FG_SYS_SCHED.last_end_date
  is 'LAST_END_DATE';

prompt
prompt Creating table FG_S_CUSTOMER_PIVOT
prompt ==================================
prompt
create table FG_S_CUSTOMER_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  creation_date   DATE,
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  change_by       VARCHAR2(100),
  created_by      VARCHAR2(100),
  sessionid       VARCHAR2(100),
  active          NUMBER,
  formcode_entity VARCHAR2(100),
  formcode        VARCHAR2(100),
  customername    VARCHAR2(500),
  description     VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_DYNAMICREPORTSQL_PIVOT
prompt ==========================================
prompt
create table FG_S_DYNAMICREPORTSQL_PIVOT
(
  formid               VARCHAR2(100) not null,
  timestamp            DATE,
  creation_date        DATE,
  cloneid              VARCHAR2(100),
  templateflag         VARCHAR2(100),
  change_by            VARCHAR2(100),
  created_by           VARCHAR2(100),
  sessionid            VARCHAR2(100),
  active               NUMBER,
  formcode_entity      VARCHAR2(100),
  formcode             VARCHAR2(100),
  execute              VARCHAR2(500),
  sqltext              VARCHAR2(500),
  dynamicreportsqlname VARCHAR2(500),
  systemreport         VARCHAR2(500),
  sqlresulttable       VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_GROUPSCREW_PIVOT
prompt ====================================
prompt
create table FG_S_GROUPSCREW_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  change_by       VARCHAR2(100),
  sessionid       VARCHAR2(100),
  active          NUMBER,
  formcode        VARCHAR2(100),
  group_id        VARCHAR2(500),
  parentid        VARCHAR2(500),
  groupscrewname  VARCHAR2(500),
  formcode_entity VARCHAR2(100),
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  created_by      VARCHAR2(100),
  creation_date   DATE
)
;

prompt
prompt Creating table FG_S_GROUP_PIVOT
prompt ===============================
prompt
create table FG_S_GROUP_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  change_by       VARCHAR2(100),
  sessionid       VARCHAR2(500),
  active          NUMBER,
  formcode        VARCHAR2(100),
  groupname       VARCHAR2(500),
  selectuser      VARCHAR2(500),
  grouptype       VARCHAR2(500),
  description     VARCHAR2(4000),
  site_id         VARCHAR2(500),
  formcode_entity VARCHAR2(100),
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  created_by      VARCHAR2(100),
  creation_date   DATE default sysdate
)
;

prompt
prompt Creating table FG_S_LABORATORY_PIVOT
prompt ====================================
prompt
create table FG_S_LABORATORY_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  change_by       VARCHAR2(100),
  sessionid       VARCHAR2(100),
  active          NUMBER,
  formcode        VARCHAR2(100),
  laboratoryname  VARCHAR2(500),
  formnumberid    VARCHAR2(500),
  units_id        VARCHAR2(500),
  site_id         VARCHAR2(500),
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  formcode_entity VARCHAR2(100),
  lab_manager_id  VARCHAR2(500),
  created_by      VARCHAR2(100),
  creation_date   DATE
)
;
create unique index LABORATORY_ID_UNIQUE on FG_S_LABORATORY_PIVOT (TRIM(UPPER(FORMNUMBERID)));

prompt
prompt Creating table FG_S_PERMISSIONOBJECT_PIVOT
prompt ==========================================
prompt
create table FG_S_PERMISSIONOBJECT_PIVOT
(
  formid                 VARCHAR2(100) not null,
  timestamp              DATE,
  change_by              VARCHAR2(100),
  sessionid              VARCHAR2(500),
  active                 NUMBER,
  formcode_entity        VARCHAR2(100),
  formcode               VARCHAR2(100),
  permissionobjectname   VARCHAR2(500),
  lab                    VARCHAR2(500),
  site                   VARCHAR2(500),
  unit                   VARCHAR2(500),
  objectsinherit         VARCHAR2(500),
  cloneid                VARCHAR2(100),
  templateflag           VARCHAR2(100),
  objectsinheritoncreate VARCHAR2(500),
  created_by             VARCHAR2(100),
  creation_date          DATE default sysdate
)
;

prompt
prompt Creating table FG_S_PERMISSIONPOLICY_PIVOT
prompt ==========================================
prompt
create table FG_S_PERMISSIONPOLICY_PIVOT
(
  formid               VARCHAR2(100) not null,
  timestamp            DATE,
  change_by            VARCHAR2(100),
  sessionid            VARCHAR2(500),
  active               NUMBER,
  formcode             VARCHAR2(100),
  customer_id          VARCHAR2(500),
  userrole_id          VARCHAR2(500),
  permissionpolicyname VARCHAR2(500),
  policyexpression     VARCHAR2(500),
  policypermission     VARCHAR2(500),
  cloneid              VARCHAR2(100),
  templateflag         VARCHAR2(100),
  formcode_entity      VARCHAR2(100)
)
;

prompt
prompt Creating table FG_S_PERMISSIONSCHEME_PIVOT
prompt ==========================================
prompt
create table FG_S_PERMISSIONSCHEME_PIVOT
(
  formid               VARCHAR2(100) not null,
  timestamp            DATE,
  change_by            VARCHAR2(100),
  sessionid            VARCHAR2(100),
  active               NUMBER,
  formcode_entity      VARCHAR2(100),
  formcode             VARCHAR2(100),
  permissionschemename VARCHAR2(500),
  users                VARCHAR2(500),
  permissiontable      VARCHAR2(500),
  groupscrew           VARCHAR2(500),
  screen               VARCHAR2(500),
  cloneid              VARCHAR2(100),
  templateflag         VARCHAR2(100),
  created_by           VARCHAR2(100),
  creation_date        DATE,
  maintenanceformlist  VARCHAR2(1000)
)
;

prompt
prompt Creating table FG_S_PERMISSIONSREF_PIVOT
prompt ========================================
prompt
create table FG_S_PERMISSIONSREF_PIVOT
(
  formid             VARCHAR2(100) not null,
  timestamp          DATE,
  change_by          VARCHAR2(100),
  sessionid          VARCHAR2(500),
  active             NUMBER,
  formcode_entity    VARCHAR2(100),
  formcode           VARCHAR2(100),
  parentid           VARCHAR2(500),
  permission         VARCHAR2(500),
  permissionsrefname VARCHAR2(500),
  lab_id             VARCHAR2(500),
  unit_id            VARCHAR2(500),
  site_id            VARCHAR2(500),
  tabletype          VARCHAR2(500),
  cloneid            VARCHAR2(100),
  templateflag       VARCHAR2(100),
  created_by         VARCHAR2(100),
  creation_date      DATE default sysdate
)
;

prompt
prompt Creating table FG_S_SENSITIVITYLEVEL_PIVOT
prompt ==========================================
prompt
create table FG_S_SENSITIVITYLEVEL_PIVOT
(
  formid                VARCHAR2(100) not null,
  timestamp             DATE,
  change_by             VARCHAR2(100),
  sessionid             VARCHAR2(500),
  active                NUMBER,
  formcode              VARCHAR2(100),
  customer_id           VARCHAR2(500),
  sensitivitylevelname  VARCHAR2(500),
  description           VARCHAR2(500),
  formcode_entity       VARCHAR2(100),
  sensitivitylevelorder VARCHAR2(500),
  cloneid               VARCHAR2(100),
  templateflag          VARCHAR2(100),
  created_by            VARCHAR2(100),
  creation_date         DATE default sysdate
)
;

prompt
prompt Creating table FG_S_SITE_PIVOT
prompt ==============================
prompt
create table FG_S_SITE_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  change_by       VARCHAR2(100),
  sessionid       VARCHAR2(500),
  active          NUMBER,
  formcode        VARCHAR2(100),
  customer_id     VARCHAR2(500),
  sitename        VARCHAR2(500),
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  formcode_entity VARCHAR2(100),
  created_by      VARCHAR2(100),
  creation_date   DATE default sysdate
)
;

prompt
prompt Creating table FG_S_SYSCONFDTCRITERIA_PIVOT
prompt ===========================================
prompt
create table FG_S_SYSCONFDTCRITERIA_PIVOT
(
  formid                VARCHAR2(100) not null,
  timestamp             DATE,
  cloneid               VARCHAR2(100),
  templateflag          VARCHAR2(100),
  change_by             VARCHAR2(100),
  sessionid             VARCHAR2(500),
  active                NUMBER,
  formcode_entity       VARCHAR2(100),
  formcode              VARCHAR2(100),
  sysconfdtcriterianame VARCHAR2(4000),
  argformcode           VARCHAR2(4000),
  argstruct             VARCHAR2(4000),
  sysconfsqlpool_id     VARCHAR2(4000),
  created_by            VARCHAR2(100),
  creation_date         DATE default sysdate
)
;

prompt
prompt Creating table FG_S_SYSCONFEXCELDATA_PIVOT
prompt ==========================================
prompt
create table FG_S_SYSCONFEXCELDATA_PIVOT
(
  formid               VARCHAR2(100) not null,
  timestamp            DATE,
  creation_date        DATE,
  cloneid              VARCHAR2(100),
  templateflag         VARCHAR2(100),
  change_by            VARCHAR2(100),
  created_by           VARCHAR2(100),
  sessionid            VARCHAR2(100),
  active               NUMBER,
  formcode_entity      VARCHAR2(100),
  formcode             VARCHAR2(100),
  sysconfexceldataname VARCHAR2(500),
  excelfile            VARCHAR2(500),
  exceldata            VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_SYSCONFPRESAVECALC_PIVOT
prompt ============================================
prompt
create table FG_S_SYSCONFPRESAVECALC_PIVOT
(
  formid                 VARCHAR2(100) not null,
  timestamp              DATE,
  change_by              VARCHAR2(100),
  sessionid              VARCHAR2(500),
  active                 NUMBER,
  formcode               VARCHAR2(100),
  arg3                   VARCHAR2(500),
  resultelement          VARCHAR2(500),
  arg4                   VARCHAR2(500),
  formulaorfunction      VARCHAR2(500),
  sysconfpresavecalcname VARCHAR2(500),
  arg5                   VARCHAR2(500),
  argelement             VARCHAR2(500),
  arg2                   VARCHAR2(500),
  arg1                   VARCHAR2(500),
  cloneid                VARCHAR2(100),
  templateflag           VARCHAR2(100),
  formcode_entity        VARCHAR2(100)
)
;

prompt
prompt Creating table FG_S_SYSCONFSQLCRITERIA_PIVOT
prompt ============================================
prompt
create table FG_S_SYSCONFSQLCRITERIA_PIVOT
(
  formid                 VARCHAR2(100) not null,
  timestamp              DATE,
  creation_date          DATE,
  cloneid                VARCHAR2(100),
  templateflag           VARCHAR2(100),
  change_by              VARCHAR2(100),
  created_by             VARCHAR2(100),
  sessionid              VARCHAR2(100),
  active                 NUMBER,
  formcode_entity        VARCHAR2(100),
  formcode               VARCHAR2(100),
  sqldescription         VARCHAR2(4000),
  additionalmatchinfo    VARCHAR2(500),
  structlevel            VARCHAR2(500),
  sqltext                VARCHAR2(4000),
  sysconfsqlcriterianame VARCHAR2(500),
  ignore                 VARCHAR2(500),
  executationtype        VARCHAR2(500),
  screen                 VARCHAR2(500),
  isdefault              VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_SYSCONFSQLCRITERIA_PIVOT1
prompt =============================================
prompt
create table FG_S_SYSCONFSQLCRITERIA_PIVOT1
(
  formid                 VARCHAR2(100) not null,
  timestamp              DATE,
  creation_date          DATE,
  cloneid                VARCHAR2(100),
  templateflag           VARCHAR2(100),
  change_by              VARCHAR2(100),
  created_by             VARCHAR2(100),
  sessionid              VARCHAR2(100),
  active                 NUMBER,
  formcode_entity        VARCHAR2(100),
  formcode               VARCHAR2(100),
  sqltype                VARCHAR2(500),
  sqldescription         VARCHAR2(4000),
  structlevel            VARCHAR2(500),
  sqltext                VARCHAR2(4000),
  ignore                 VARCHAR2(500),
  sysconfsqlcriterianame VARCHAR2(500),
  executationtype        VARCHAR2(500),
  isdefault              VARCHAR2(500),
  screen                 VARCHAR2(500),
  additionalmatchinfo    VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_SYSCONFSQLPOOL_PIVOT
prompt ========================================
prompt
create table FG_S_SYSCONFSQLPOOL_PIVOT
(
  formid             VARCHAR2(100) not null,
  timestamp          DATE,
  cloneid            VARCHAR2(100),
  templateflag       VARCHAR2(100),
  change_by          VARCHAR2(100),
  sessionid          VARCHAR2(500),
  active             NUMBER,
  formcode_entity    VARCHAR2(100),
  formcode           VARCHAR2(100),
  sqltype            VARCHAR2(500),
  sqldescription     VARCHAR2(4000),
  sysconfsqlpoolname VARCHAR2(500),
  sqltext            VARCHAR2(4000),
  structlevel        VARCHAR2(500),
  ignore             VARCHAR2(500),
  executationtype    VARCHAR2(500),
  screen             VARCHAR2(500),
  isdefault          VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_SYSCONFWFNEW_PIVOT
prompt ======================================
prompt
create table FG_S_SYSCONFWFNEW_PIVOT
(
  formid           VARCHAR2(100) not null,
  timestamp        DATE,
  change_by        VARCHAR2(100),
  sessionid        VARCHAR2(500),
  active           NUMBER,
  formcode         CHAR(12),
  parammapname     VARCHAR2(4000),
  parammapval      VARCHAR2(4000),
  removefromlist   VARCHAR2(4000),
  sysconfwfnewname VARCHAR2(4000),
  jsonname         VARCHAR2(4000)
)
;

prompt
prompt Creating table FG_S_SYSCONFWFSTATUS_PIVOT
prompt =========================================
prompt
create table FG_S_SYSCONFWFSTATUS_PIVOT
(
  formid              VARCHAR2(100) not null,
  timestamp           DATE,
  creation_date       DATE,
  cloneid             VARCHAR2(100),
  templateflag        VARCHAR2(100),
  change_by           VARCHAR2(100),
  created_by          VARCHAR2(100),
  sessionid           VARCHAR2(100),
  active              NUMBER,
  formcode_entity     VARCHAR2(100),
  formcode            VARCHAR2(100),
  wherepartparmname   VARCHAR2(500),
  sysconfwfstatusname VARCHAR2(500),
  statusformcode      VARCHAR2(500),
  statusinfcolumn     VARCHAR2(500),
  jsonname            VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_SYSEVENTHANDLERREF_PIVOT
prompt ============================================
prompt
create table FG_S_SYSEVENTHANDLERREF_PIVOT
(
  formid                 VARCHAR2(100) not null,
  timestamp              DATE,
  change_by              VARCHAR2(100),
  sessionid              VARCHAR2(500),
  active                 NUMBER,
  formcode               VARCHAR2(100),
  handlerorderonfail     VARCHAR2(4000),
  parentid               VARCHAR2(4000),
  tabletype              VARCHAR2(4000),
  syseventhandlerrefname VARCHAR2(4000),
  handlerorder           VARCHAR2(4000),
  created_by             VARCHAR2(100),
  creation_date          DATE default sysdate
)
;

prompt
prompt Creating table FG_S_SYSEVENTHANDLERSET_PIVOT
prompt ============================================
prompt
create table FG_S_SYSEVENTHANDLERSET_PIVOT
(
  formid                 VARCHAR2(100) not null,
  timestamp              DATE,
  change_by              VARCHAR2(100),
  sessionid              VARCHAR2(500),
  active                 NUMBER,
  formcode               VARCHAR2(100),
  handlerorderonfail     VARCHAR2(4000),
  handlersetcomment      VARCHAR2(4000),
  handlerorder           VARCHAR2(4000),
  syseventpoint_id       VARCHAR2(4000),
  syseventhandlersetname VARCHAR2(4000),
  cloneid                VARCHAR2(100),
  templateflag           VARCHAR2(100),
  formcode_entity        VARCHAR2(100),
  created_by             VARCHAR2(100),
  creation_date          DATE default sysdate
)
;

prompt
prompt Creating table FG_S_SYSEVENTHANDLER_PIVOT
prompt =========================================
prompt
create table FG_S_SYSEVENTHANDLER_PIVOT
(
  formid                VARCHAR2(100) not null,
  timestamp             DATE,
  creation_date         DATE,
  cloneid               VARCHAR2(100),
  templateflag          VARCHAR2(100),
  change_by             VARCHAR2(100),
  created_by            VARCHAR2(100),
  sessionid             VARCHAR2(100),
  active                NUMBER,
  formcode_entity       VARCHAR2(100),
  formcode              VARCHAR2(100),
  handlervalidation     VARCHAR2(500),
  syseventhandlername   VARCHAR2(500),
  calcarg               VARCHAR2(500),
  handlerorder          VARCHAR2(500),
  syseventpointfullname VARCHAR2(500),
  handlerdescription    VARCHAR2(500),
  handlerunittest       VARCHAR2(500),
  calcformula           VARCHAR2(4000)
)
;

prompt
prompt Creating table FG_S_SYSEVENTHANDLETYPE_PIVOT
prompt ============================================
prompt
create table FG_S_SYSEVENTHANDLETYPE_PIVOT
(
  formid                 VARCHAR2(100) not null,
  timestamp              DATE,
  creation_date          DATE default sysdate,
  cloneid                VARCHAR2(100),
  templateflag           VARCHAR2(100),
  change_by              VARCHAR2(100),
  created_by             VARCHAR2(100),
  sessionid              VARCHAR2(500),
  active                 NUMBER,
  formcode_entity        VARCHAR2(100),
  formcode               VARCHAR2(100),
  syseventhandletypename VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_SYSEVENTMANAGER_PIVOT
prompt =========================================
prompt
create table FG_S_SYSEVENTMANAGER_PIVOT
(
  formid              VARCHAR2(100) not null,
  timestamp           DATE,
  change_by           VARCHAR2(100),
  sessionid           VARCHAR2(500),
  active              NUMBER,
  formcode            VARCHAR2(100),
  handlerset          VARCHAR2(4000),
  formcodematch       VARCHAR2(4000),
  syseventmanagername VARCHAR2(4000),
  syseventtype_id     VARCHAR2(4000)
)
;

prompt
prompt Creating table FG_S_SYSEVENTPOINT_PIVOT
prompt =======================================
prompt
create table FG_S_SYSEVENTPOINT_PIVOT
(
  formid            VARCHAR2(100) not null,
  timestamp         DATE,
  creation_date     DATE,
  cloneid           VARCHAR2(100),
  templateflag      VARCHAR2(100),
  change_by         VARCHAR2(100),
  created_by        VARCHAR2(100),
  sessionid         VARCHAR2(100),
  active            NUMBER,
  formcode_entity   VARCHAR2(100),
  formcode          VARCHAR2(100),
  additionalmatch   VARCHAR2(500),
  formcodematch     VARCHAR2(500),
  syseventypename   VARCHAR2(500),
  syseventpointname VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_SYSEVENTTYPE_PIVOT
prompt ======================================
prompt
create table FG_S_SYSEVENTTYPE_PIVOT
(
  formid           VARCHAR2(100) not null,
  timestamp        DATE,
  creation_date    DATE default sysdate,
  cloneid          VARCHAR2(100),
  templateflag     VARCHAR2(100),
  change_by        VARCHAR2(100),
  created_by       VARCHAR2(100),
  sessionid        VARCHAR2(500),
  active           NUMBER,
  formcode_entity  VARCHAR2(100),
  formcode         VARCHAR2(100),
  syseventtypename VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_TESTAD_PIVOT
prompt ================================
prompt
create table FG_S_TESTAD_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  creation_date   DATE,
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  change_by       VARCHAR2(100),
  created_by      VARCHAR2(100),
  sessionid       VARCHAR2(100),
  active          NUMBER,
  formcode_entity VARCHAR2(100),
  formcode        VARCHAR2(100),
  ad8             VARCHAR2(500),
  ad9             VARCHAR2(500),
  testadname      VARCHAR2(500),
  ad10            VARCHAR2(500),
  d2              VARCHAR2(500),
  cta             VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_TESTCUBE_PIVOT
prompt ==================================
prompt
create table FG_S_TESTCUBE_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  creation_date   DATE,
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  change_by       VARCHAR2(100),
  created_by      VARCHAR2(100),
  sessionid       VARCHAR2(100),
  active          NUMBER,
  formcode_entity VARCHAR2(100),
  formcode        VARCHAR2(100),
  testcubename    VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_TESTDELETION_PIVOT
prompt ======================================
prompt
create table FG_S_TESTDELETION_PIVOT
(
  formid           VARCHAR2(100) not null,
  timestamp        DATE,
  creation_date    DATE,
  cloneid          VARCHAR2(100),
  templateflag     VARCHAR2(100),
  change_by        VARCHAR2(100),
  created_by       VARCHAR2(100),
  sessionid        VARCHAR2(100),
  active           NUMBER,
  formcode_entity  VARCHAR2(100),
  formcode         VARCHAR2(100),
  testdeletionname VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_TESTFORM_PIVOT
prompt ==================================
prompt
create table FG_S_TESTFORM_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  creation_date   DATE,
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  change_by       VARCHAR2(100),
  created_by      VARCHAR2(100),
  sessionid       VARCHAR2(100),
  active          NUMBER,
  formcode_entity VARCHAR2(100),
  formcode        VARCHAR2(100),
  rt1             VARCHAR2(500),
  testformname    VARCHAR2(500),
  approver_id     VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_UNITS_PIVOT
prompt ===============================
prompt
create table FG_S_UNITS_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  change_by       VARCHAR2(100),
  sessionid       VARCHAR2(500),
  active          NUMBER,
  formcode        VARCHAR2(100),
  unitsname       VARCHAR2(500),
  site_id         VARCHAR2(500),
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  formcode_entity VARCHAR2(100),
  created_by      VARCHAR2(100),
  creation_date   DATE default sysdate
)
;

prompt
prompt Creating table FG_S_UNITTESTCONFIG_PIVOT
prompt ========================================
prompt
create table FG_S_UNITTESTCONFIG_PIVOT
(
  formid                 VARCHAR2(100) not null,
  timestamp              DATE,
  change_by              VARCHAR2(100),
  sessionid              VARCHAR2(100),
  active                 NUMBER,
  formcode_entity        VARCHAR2(100),
  formcode               VARCHAR2(100),
  orderofexecution       VARCHAR2(500),
  unittestconfigname     VARCHAR2(500),
  unittestaction         VARCHAR2(500),
  ignoretest             VARCHAR2(500),
  waitingtime            VARCHAR2(500),
  entityimpname          VARCHAR2(500),
  testingformcode        VARCHAR2(500),
  fieldvalue             VARCHAR2(4000),
  unittestconfigcomments VARCHAR2(500),
  cloneid                VARCHAR2(100),
  templateflag           VARCHAR2(100),
  created_by             VARCHAR2(100),
  creation_date          DATE,
  groupname              VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_UNITTESTGROUP_PIVOT
prompt =======================================
prompt
create table FG_S_UNITTESTGROUP_PIVOT
(
  formid            VARCHAR2(100) not null,
  timestamp         DATE,
  change_by         VARCHAR2(100),
  sessionid         VARCHAR2(500),
  active            NUMBER,
  formcode_entity   VARCHAR2(100),
  formcode          VARCHAR2(100),
  orderofexecution  VARCHAR2(500),
  ignore            VARCHAR2(500),
  unittestgroupname VARCHAR2(500),
  unittestlevels    VARCHAR2(500),
  comments          VARCHAR2(500),
  cloneid           VARCHAR2(100),
  templateflag      VARCHAR2(100),
  created_by        VARCHAR2(100),
  creation_date     DATE default sysdate
)
;

prompt
prompt Creating table FG_S_UOMTYPE_PIVOT
prompt =================================
prompt
create table FG_S_UOMTYPE_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  change_by       VARCHAR2(100),
  sessionid       VARCHAR2(500),
  active          NUMBER,
  formcode        VARCHAR2(100),
  uomtypename     VARCHAR2(500),
  formcode_entity VARCHAR2(100),
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  created_by      VARCHAR2(100),
  creation_date   DATE default sysdate
)
;
create unique index UOMTYPE_UNIQUE on FG_S_UOMTYPE_PIVOT (TRIM(UPPER(UOMTYPENAME)), TRIM(UPPER(TO_CHAR(ACTIVE))));

prompt
prompt Creating table FG_S_UOM_PIVOT
prompt =============================
prompt
create table FG_S_UOM_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  change_by       VARCHAR2(100),
  sessionid       VARCHAR2(500),
  active          NUMBER,
  formcode        VARCHAR2(100),
  isnormal        VARCHAR2(500),
  factor          VARCHAR2(500),
  precision       VARCHAR2(500),
  uomname         VARCHAR2(500),
  type            VARCHAR2(500),
  formcode_entity VARCHAR2(100),
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  created_by      VARCHAR2(100),
  creation_date   DATE default sysdate
)
;
create unique index UOM_UNIQUE on FG_S_UOM_PIVOT (TRIM(UPPER(TO_CHAR(ACTIVE))), TRIM(UPPER(UOMNAME)), TRIM(UPPER(TYPE)));

prompt
prompt Creating table FG_S_USERGUIDEPOOL_PIVOT
prompt =======================================
prompt
create table FG_S_USERGUIDEPOOL_PIVOT
(
  formid               VARCHAR2(100) not null,
  timestamp            DATE,
  creation_date        DATE,
  cloneid              VARCHAR2(100),
  templateflag         VARCHAR2(100),
  change_by            VARCHAR2(100),
  created_by           VARCHAR2(100),
  sessionid            VARCHAR2(100),
  active               NUMBER,
  formcode_entity      VARCHAR2(100),
  formcode             VARCHAR2(100),
  userguidedescription VARCHAR2(4000),
  userguidefile        VARCHAR2(500),
  itemorder            VARCHAR2(500),
  userguidepoolname    VARCHAR2(500)
)
;

prompt
prompt Creating table FG_S_USERGUIDEVIDEOPOOL_PIVOT
prompt ============================================
prompt
create table FG_S_USERGUIDEVIDEOPOOL_PIVOT
(
  formid               VARCHAR2(100) not null,
  timestamp            DATE,
  creation_date        DATE,
  cloneid              VARCHAR2(100),
  templateflag         VARCHAR2(100),
  change_by            VARCHAR2(100),
  created_by           VARCHAR2(100),
  sessionid            VARCHAR2(100),
  active               NUMBER,
  formcode_entity      VARCHAR2(100),
  formcode             VARCHAR2(100),
  userguidedescription VARCHAR2(4000),
  userguidefile        VARCHAR2(4000),
  userguidename        VARCHAR2(4000)
)
;

prompt
prompt Creating table FG_S_USERROLE_PIVOT
prompt ==================================
prompt
create table FG_S_USERROLE_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  change_by       VARCHAR2(100),
  sessionid       VARCHAR2(500),
  active          NUMBER,
  formcode        VARCHAR2(100),
  customer_id     VARCHAR2(500),
  userrolename    VARCHAR2(500),
  formcode_entity VARCHAR2(100),
  cloneid         VARCHAR2(100),
  templateflag    VARCHAR2(100),
  created_by      VARCHAR2(100),
  creation_date   DATE default sysdate
)
;

prompt
prompt Creating table FG_S_USERSCREW_PIVOT
prompt ===================================
prompt
create table FG_S_USERSCREW_PIVOT
(
  formid          VARCHAR2(100) not null,
  timestamp       DATE,
  change_by       VARCHAR2(100),
  sessionid       VARCHAR2(100),
  active          NUMBER,
  formcode        VARCHAR2(100),
  userscrewname   VARCHAR2(500),
  parentid        VARCHAR2(500),
  user_id         VARCHAR2(500),
  formcode_entity VARCHAR2(100),
  cloneid         VARCHAR2(100),
  disabled        VARCHAR2(500),
  templateflag    VARCHAR2(100),
  created_by      VARCHAR2(100),
  creation_date   DATE
)
;

prompt
prompt Creating table FG_S_USER_PIVOT
prompt ==============================
prompt
create table FG_S_USER_PIVOT
(
  formid                VARCHAR2(100) not null,
  timestamp             DATE,
  change_by             VARCHAR2(100),
  sessionid             VARCHAR2(100),
  active                NUMBER,
  formcode              VARCHAR2(100),
  username              VARCHAR2(500),
  position              VARCHAR2(500),
  firstname             VARCHAR2(500),
  lastname              VARCHAR2(500),
  changepassword        VARCHAR2(500),
  deleted               VARCHAR2(500),
  locked                VARCHAR2(500),
  customer_id           VARCHAR2(500),
  userrole_id           VARCHAR2(500),
  userldap              VARCHAR2(500),
  passworddate          VARCHAR2(500),
  chgpassworddate       VARCHAR2(500),
  laboratory_id         VARCHAR2(500),
  unit_id               VARCHAR2(500),
  password              VARCHAR2(500),
  lastretry             VARCHAR2(500),
  retrycount            VARCHAR2(500),
  site_id               VARCHAR2(500),
  email                 VARCHAR2(500),
  lastpassworddate      VARCHAR2(500),
  formcode_entity       VARCHAR2(100),
  teamleader_id         VARCHAR2(500),
  groupscrew            VARCHAR2(500),
  cloneid               VARCHAR2(100),
  permissiontable       VARCHAR2(500),
  sensitivitylevel_id   VARCHAR2(500),
  templateflag          VARCHAR2(100),
  created_by            VARCHAR2(100),
  creation_date         DATE,
  messagecheckinterval  VARCHAR2(500),
  lastnotificationcheck VARCHAR2(500),
  last_breadcrumb_link  VARCHAR2(500)
)
;
create unique index USER_NAME_UNIQUE on FG_S_USER_PIVOT (TRIM(UPPER(USERNAME)));

prompt
prompt Creating table FG_S_USER_PIVOT_TMP
prompt ==================================
prompt
create table FG_S_USER_PIVOT_TMP
(
  formid           VARCHAR2(100) not null,
  time_stamp       DATE,
  created_by       VARCHAR2(100) not null,
  password         VARCHAR2(500),
  firstname        VARCHAR2(500),
  userldap         VARCHAR2(500),
  username         VARCHAR2(500),
  passworddate     VARCHAR2(500),
  chgpassworddate  VARCHAR2(500),
  lastname         VARCHAR2(500),
  userrole_id      VARCHAR2(500),
  lastentry        VARCHAR2(500),
  email            VARCHAR2(500),
  retrycount       VARCHAR2(500),
  changepassword   VARCHAR2(500),
  locked           VARCHAR2(500),
  lastpassworddate VARCHAR2(500)
)
;

prompt
prompt Creating table FG_TOOL_INF_ALL_DATA
prompt ===================================
prompt
create table FG_TOOL_INF_ALL_DATA
(
  name      VARCHAR2(4000),
  id        VARCHAR2(100),
  tablename VARCHAR2(29)
)
;

prompt
prompt Creating table FG_TREE_SEARCH_ID_TMP
prompt ====================================
prompt
create global temporary table FG_TREE_SEARCH_ID_TMP
(
  id NUMBER not null
)
on commit preserve rows;

prompt
prompt Creating table FG_UNITEST_LOG
prompt =============================
prompt
create table FG_UNITEST_LOG
(
  user_id              VARCHAR2(4000),
  unittestgroupname    VARCHAR2(4000),
  message              VARCHAR2(4000),
  action               VARCHAR2(4000),
  waitingtime          VARCHAR2(4000),
  test_status          VARCHAR2(100),
  time_stamp           DATE,
  fieldvalue           VARCHAR2(4000),
  unitestlogid         VARCHAR2(100) not null,
  unitestconfigform_id VARCHAR2(100),
  id                   NUMBER
)
;

prompt
prompt Creating table FG_UNITEST_LOG_HST
prompt =================================
prompt
create table FG_UNITEST_LOG_HST
(
  user_id              VARCHAR2(4000),
  unittestgroupname    VARCHAR2(4000),
  message              VARCHAR2(4000),
  action               VARCHAR2(4000),
  waitingtime          VARCHAR2(4000),
  test_status          VARCHAR2(100),
  time_stamp           DATE,
  fieldvalue           VARCHAR2(4000),
  unitestlogid         VARCHAR2(100) not null,
  unitestconfigform_id VARCHAR2(100),
  id                   NUMBER
)
;

prompt
prompt Creating table FG_UNITTEST_AT_SEQUENCE
prompt ======================================
prompt
create table FG_UNITTEST_AT_SEQUENCE
(
  unittest_at_id NUMBER not null,
  timestamp      DATE
)
;

prompt
prompt Creating table FG_UNITTEST_SEQUENCE
prompt ===================================
prompt
create table FG_UNITTEST_SEQUENCE
(
  unittest_id   NUMBER not null,
  unittest_name VARCHAR2(100),
  timestamp     DATE
)
;

prompt
prompt Creating table FG_WEBIX_OUTPUT
prompt ==============================
prompt
create table FG_WEBIX_OUTPUT
(
  result_id            VARCHAR2(100),
  step_id              VARCHAR2(4000),
  batch_id             VARCHAR2(4000),
  result_name          VARCHAR2(4000),
  result_value         VARCHAR2(500),
  result_type          CHAR(500),
  result_date          DATE default sysdate,
  result_time          VARCHAR2(8) default to_char( sysdate, 'HH24:MI:SS' ),
  result_comment       VARCHAR2(500),
  result_is_active     CHAR(500),
  result_test_name     VARCHAR2(4000),
  mass                 VARCHAR2(100),
  experiment_id        VARCHAR2(4000),
  material_id          VARCHAR2(4000),
  result_uom_id        VARCHAR2(500),
  samples              VARCHAR2(500),
  weight               VARCHAR2(100),
  moles                VARCHAR2(100),
  yield                VARCHAR2(100),
  indication_mb        VARCHAR2(4000),
  sample_mb            VARCHAR2(4000),
  component_id         VARCHAR2(4000),
  preparationref_id    VARCHAR2(4000),
  sample_id            VARCHAR2(4000),
  analytic_data        VARCHAR2(4000),
  weighting            VARCHAR2(4000),
  stream_data          VARCHAR2(4000),
  webix_change_by      VARCHAR2(100),
  table_index_mb       VARCHAR2(5),
  table_group_index_mb VARCHAR2(1)
)
;
comment on column FG_WEBIX_OUTPUT.table_index_mb
  is 'the order of the tables in a single tab';
comment on column FG_WEBIX_OUTPUT.table_group_index_mb
  is 'the number of the tab in which the stream is displayed';

prompt
prompt Creating table FG_WEBIX_OUTPUT_HST
prompt ==================================
prompt
create table FG_WEBIX_OUTPUT_HST
(
  result_id         VARCHAR2(100),
  step_id           VARCHAR2(4000),
  batch_id          VARCHAR2(4000),
  result_name       VARCHAR2(4000),
  result_value      VARCHAR2(500),
  result_type       CHAR(500),
  result_date       DATE,
  result_time       VARCHAR2(8),
  result_comment    VARCHAR2(500),
  result_is_active  CHAR(500),
  result_test_name  VARCHAR2(4000),
  mass              VARCHAR2(100),
  experiment_id     VARCHAR2(4000),
  material_id       VARCHAR2(4000),
  result_uom_id     VARCHAR2(500),
  samples           VARCHAR2(500),
  weight            VARCHAR2(100),
  moles             VARCHAR2(100),
  yield             VARCHAR2(100),
  indication_mb     VARCHAR2(4000),
  sample_mb         VARCHAR2(4000),
  component_id      VARCHAR2(4000),
  preparationref_id VARCHAR2(4000),
  sample_id         VARCHAR2(4000),
  analytic_data     VARCHAR2(4000),
  weighting         VARCHAR2(4000),
  stream_data       VARCHAR2(4000),
  change_comment    VARCHAR2(500),
  change_id         NUMBER,
  change_by         NUMBER,
  change_type       VARCHAR2(1),
  change_date       DATE,
  webix_change_by   VARCHAR2(100),
  table_index_mb    VARCHAR2(5)
)
;

prompt
prompt Creating table FORMCODE_TO_DELETE
prompt =================================
prompt
create table FORMCODE_TO_DELETE
(
  formcode VARCHAR2(100)
)
;

prompt
prompt Creating table JCHEMPROPERTIES
prompt ==============================
prompt
create table JCHEMPROPERTIES
(
  prop_name      VARCHAR2(200) not null,
  prop_value     VARCHAR2(200),
  prop_value_ext BLOB
)
;
alter table JCHEMPROPERTIES
  add primary key (PROP_NAME);

prompt
prompt Creating table JCHEMPROPERTIES_CR
prompt =================================
prompt
create table JCHEMPROPERTIES_CR
(
  cache_id          VARCHAR2(32) not null,
  registration_time VARCHAR2(30) not null,
  is_protected      NUMBER(1) default 0 not null
)
;
alter table JCHEMPROPERTIES_CR
  add constraint CACHE_666270643_PK primary key (CACHE_ID);

prompt
prompt Creating table JCHEMPROPERTIES_DELETED
prompt ======================================
prompt
create table JCHEMPROPERTIES_DELETED
(
  prop_name      VARCHAR2(200) not null,
  prop_value     VARCHAR2(200),
  prop_value_ext BLOB
)
;
alter table JCHEMPROPERTIES_DELETED
  add primary key (PROP_NAME);

prompt
prompt Creating table JCHEMPROPERTIES_DELETED_CR
prompt =========================================
prompt
create table JCHEMPROPERTIES_DELETED_CR
(
  cache_id          VARCHAR2(32) not null,
  registration_time VARCHAR2(30) not null,
  is_protected      NUMBER(1) default 0 not null
)
;
alter table JCHEMPROPERTIES_DELETED_CR
  add constraint CACHE_467779596_PK primary key (CACHE_ID);

prompt
prompt Creating table JCHEMPROPERTIES_DOC
prompt ==================================
prompt
create table JCHEMPROPERTIES_DOC
(
  prop_name      VARCHAR2(200) not null,
  prop_value     VARCHAR2(200),
  prop_value_ext BLOB
)
;
alter table JCHEMPROPERTIES_DOC
  add primary key (PROP_NAME);

prompt
prompt Creating table JCHEMPROPERTIES_DOC_CR
prompt =====================================
prompt
create table JCHEMPROPERTIES_DOC_CR
(
  cache_id          VARCHAR2(32) not null,
  registration_time VARCHAR2(30) not null,
  is_protected      NUMBER(1) default 0 not null
)
;
alter table JCHEMPROPERTIES_DOC_CR
  add constraint CACHE_757297361_PK primary key (CACHE_ID);

prompt
prompt Creating table MATERIAL_TEMP_DATA
prompt =================================
prompt
create global temporary table MATERIAL_TEMP_DATA
(
  invitemmaterial_id VARCHAR2(500)
)
on commit delete rows;

prompt
prompt Creating table PIVOTDATA
prompt ========================
prompt
create global temporary table PIVOTDATA
(
  sample_experiment_id  VARCHAR2(500),
  experiment_id         VARCHAR2(500),
  step_id               VARCHAR2(500),
  action_id             NUMBER,
  colomn_name           VARCHAR2(500),
  operation             VARCHAR2(4000),
  resualt_style         CHAR(53),
  result_name           VARCHAR2(4000),
  result_value          VARCHAR2(4000),
  resultuomid_          VARCHAR2(500),
  result_id             VARCHAR2(100),
  actionname            VARCHAR2(500),
  result_type_order     NUMBER,
  disable_result_render NUMBER,
  self_test_status      VARCHAR2(500),
  resultref_id          NUMBER,
  assay_first_order     NUMBER,
  creation_date         DATE,
  sample_action_id      VARCHAR2(500),
  sample_id             VARCHAR2(500),
  material_id           VARCHAR2(500)
)
on commit delete rows;

prompt
prompt Creating sequence D_NOTIFICATION_CRITERIA_H_SEQ
prompt ===============================================
prompt
create sequence D_NOTIFICATION_CRITERIA_H_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 1150
increment by 1
cache 20;

prompt
prompt Creating sequence D_NOTIFICATION_CRITERIA_SEQ
prompt =============================================
prompt
create sequence D_NOTIFICATION_CRITERIA_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 1161
increment by 1
cache 20;

prompt
prompt Creating sequence D_NOTIF_ADDRESSEE_HST_SEQ
prompt ===========================================
prompt
create sequence D_NOTIF_ADDRESSEE_HST_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 959
increment by 1
cache 20;

prompt
prompt Creating sequence D_NOTIF_ADDRESSEE_SEQ
prompt =======================================
prompt
create sequence D_NOTIF_ADDRESSEE_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 1061
increment by 1
cache 20;

prompt
prompt Creating sequence D_NOTIF_EMAILGROUPM_LOG_SEQ
prompt =============================================
prompt
create sequence D_NOTIF_EMAILGROUPM_LOG_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 19460
increment by 1
cache 20;

prompt
prompt Creating sequence D_NOTIF_EMAIL_LOG_SEQ
prompt =======================================
prompt
create sequence D_NOTIF_EMAIL_LOG_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 121895
increment by 1
cache 20;

prompt
prompt Creating sequence D_NOTIF_MESSAGE_HST_SEQ
prompt =========================================
prompt
create sequence D_NOTIF_MESSAGE_HST_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 9838
increment by 1
cache 20;

prompt
prompt Creating sequence D_NOTIF_MESSAGE_SEQ
prompt =====================================
prompt
create sequence D_NOTIF_MESSAGE_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 1459
increment by 1
cache 20;

prompt
prompt Creating sequence FG_CHEM_DELETED_SEARCH_SQ
prompt ===========================================
prompt
create sequence FG_CHEM_DELETED_SEARCH_SQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 484
increment by 1
cache 20;

prompt
prompt Creating sequence FG_CHEM_DELETED_SEARCH_USQ
prompt ============================================
prompt
create sequence FG_CHEM_DELETED_SEARCH_USQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 488
increment by 1
cache 20;

prompt
prompt Creating sequence FG_CHEM_DOC_SEARCH_SQ
prompt =======================================
prompt
create sequence FG_CHEM_DOC_SEARCH_SQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 303
increment by 1
cache 20;

prompt
prompt Creating sequence FG_CHEM_DOC_SEARCH_USQ
prompt ========================================
prompt
create sequence FG_CHEM_DOC_SEARCH_USQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 244
increment by 1
cache 20;

prompt
prompt Creating sequence FG_CHEM_SEARCH_SQ
prompt ===================================
prompt
create sequence FG_CHEM_SEARCH_SQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 1670
increment by 1
cache 20;

prompt
prompt Creating sequence FG_CHEM_SEARCH_USQ
prompt ====================================
prompt
create sequence FG_CHEM_SEARCH_USQ
minvalue 1
maxvalue 9999999999999999999999999999
start with 2355
increment by 1
cache 20;

prompt
prompt Creating sequence FG_DYNAMICPARAMS_SEQ
prompt ======================================
prompt
create sequence FG_DYNAMICPARAMS_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 4609
increment by 1
cache 20;

prompt
prompt Creating sequence FG_FORMADDITIONALDATA_SEQ
prompt ===========================================
prompt
create sequence FG_FORMADDITIONALDATA_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 95486
increment by 1
cache 20;

prompt
prompt Creating sequence FG_FORMENTITYTYPES_SEQ
prompt ========================================
prompt
create sequence FG_FORMENTITYTYPES_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 1504
increment by 1
cache 20;

prompt
prompt Creating sequence FG_FORMENTITY_SEQ
prompt ===================================
prompt
create sequence FG_FORMENTITY_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 2167648
increment by 1
cache 20;

prompt
prompt Creating sequence FG_FORMLASTSAVEVALUE_HST_SEQ
prompt ==============================================
prompt
create sequence FG_FORMLASTSAVEVALUE_HST_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 2824
increment by 1
cache 20;

prompt
prompt Creating sequence FG_FORMLASTSAVEVALUE_INF_SEQ
prompt ==============================================
prompt
create sequence FG_FORMLASTSAVEVALUE_INF_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 1108557858
increment by 1
cache 20;

prompt
prompt Creating sequence FG_FORMLASTSAVEVALUE_SEQ
prompt ==========================================
prompt
create sequence FG_FORMLASTSAVEVALUE_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 9307585
increment by 1
cache 20;

prompt
prompt Creating sequence FG_FORM_SEQ
prompt =============================
prompt
create sequence FG_FORM_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 73775
increment by 1
cache 20;

prompt
prompt Creating sequence FG_MAINTENANCE_SITE_SEQ
prompt =========================================
prompt
create sequence FG_MAINTENANCE_SITE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

prompt
prompt Creating sequence FG_RESOURCE_SEQ
prompt =================================
prompt
create sequence FG_RESOURCE_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 166371
increment by 1
cache 20;

prompt
prompt Creating sequence FG_RESULTS_SEQ
prompt ================================
prompt
create sequence FG_RESULTS_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 7506
increment by 1
cache 20;

prompt
prompt Creating sequence FG_R_MSG_STATE_HST_SEQ
prompt ========================================
prompt
create sequence FG_R_MSG_STATE_HST_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 10381
increment by 1
cache 20;

prompt
prompt Creating sequence FG_SEQUENCE_FILES_SEQ
prompt =======================================
prompt
create sequence FG_SEQUENCE_FILES_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 307300
increment by 1
cache 15;

prompt
prompt Creating sequence FG_SEQUENCE_SEQ
prompt =================================
prompt
create sequence FG_SEQUENCE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 367746
increment by 1
cache 15;

prompt
prompt Creating sequence FG_SEQUENCE_SYSTEM_SEQ
prompt ========================================
prompt
create sequence FG_SEQUENCE_SYSTEM_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 1236
increment by 1
cache 20;

prompt
prompt Creating sequence FG_STRUCT_PROJECT_SEQ
prompt =======================================
prompt
create sequence FG_STRUCT_PROJECT_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 102
increment by 1
cache 20;

prompt
prompt Creating sequence FG_STRUCT_SUBPROJECT_SEQ
prompt ==========================================
prompt
create sequence FG_STRUCT_SUBPROJECT_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence FG_UNITEST_LOG_SEQ
prompt ====================================
prompt
create sequence FG_UNITEST_LOG_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 2320
increment by 1
cache 20;

prompt
prompt Creating sequence FG_UNITTEST_AT_SEQUENCE_SEQ
prompt =============================================
prompt
create sequence FG_UNITTEST_AT_SEQUENCE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 220
increment by 1
cache 15;

prompt
prompt Creating sequence FG_UNITTEST_SEQUENCE_SEQ
prompt ==========================================
prompt
create sequence FG_UNITTEST_SEQUENCE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 315
increment by 1
cache 15;

prompt
prompt Creating sequence FG_USER_REPORT_SEQ
prompt ====================================
prompt
create sequence FG_USER_REPORT_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 931
increment by 1
cache 20;

prompt
prompt Creating sequence FG_WEBIX_OUTPUT_SEQ
prompt =====================================
prompt
create sequence FG_WEBIX_OUTPUT_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 4234
increment by 1
cache 20;

prompt
prompt Creating sequence P_NOTIF_LISTADDRESGROUP_SEQ
prompt =============================================
prompt
create sequence P_NOTIF_LISTADDRESGROUP_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 1326
increment by 1
cache 20;

prompt
prompt Creating sequence P_NOTIF_MODULE_TYPE_SEQ
prompt =========================================
prompt
create sequence P_NOTIF_MODULE_TYPE_SEQ
minvalue 0
maxvalue 999999999999999999999999999
start with 309
increment by 1
cache 20;

prompt
prompt Creating view FG_S_CUSTOMER_V
prompt =============================
prompt
create or replace view fg_s_customer_v as
select to_number(t.formid) as customer_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.CustomerName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as Customer_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."CUSTOMERNAME",t."DESCRIPTION"
      from FG_S_CUSTOMER_PIVOT t;

prompt
prompt Creating view FG_S_CUSTOMER_ALL_V
prompt =================================
prompt
create or replace view fg_s_customer_all_v as
select t."CUSTOMER_ID",t."FORM_TEMP_ID",t."CUSTOMER_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."CUSTOMERNAME",t."DESCRIPTION"
--t.* end! edit only the code below...
              from FG_S_CUSTOMER_V t;

prompt
prompt Creating view FG_AUTHEN_CUSTOMER_V
prompt ==================================
prompt
create or replace view fg_authen_customer_v as
select "CUSTOMER_ID","FORM_TEMP_ID","CUSTOMER_OBJIDVAL","FORMID","TIMESTAMP","CREATION_DATE","CLONEID","TEMPLATEFLAG","CHANGE_BY","CREATED_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","CUSTOMERNAME"
              from FG_S_CUSTOMER_ALL_V;

prompt
prompt Creating view FG_S_DYNAMICREPORTSQL_V
prompt =====================================
prompt
create or replace view fg_s_dynamicreportsql_v as
select to_number(t.formid) as dynamicreportsql_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.DynamicReportSqlName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as DynamicReportSql_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."EXECUTE",t."SQLTEXT",t."DYNAMICREPORTSQLNAME",t."SYSTEMREPORT",t."SQLRESULTTABLE"
      from FG_S_DYNAMICREPORTSQL_PIVOT t;

prompt
prompt Creating view FG_S_DYNAMICREPORTSQL_ALL_V
prompt =========================================
prompt
create or replace view fg_s_dynamicreportsql_all_v as
select t."DYNAMICREPORTSQL_ID",t."FORM_TEMP_ID",t."DYNAMICREPORTSQL_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."EXECUTE",t."SQLTEXT",t."DYNAMICREPORTSQLNAME",t."SYSTEMREPORT",t."SQLRESULTTABLE"
--t.* end! edit only the code below...
,c.file_content as SQLTEXT_CONTENT
              from FG_S_DYNAMICREPORTSQL_V t,
                   fg_clob_files c
              where t.SQLTEXT = c.file_id;

prompt
prompt Creating view FG_AUTHEN_DYNAMICREPORTSQL_V
prompt ==========================================
prompt
create or replace view fg_authen_dynamicreportsql_v as
select "DYNAMICREPORTSQL_ID","FORM_TEMP_ID","DYNAMICREPORTSQL_OBJIDVAL","FORMID","TIMESTAMP","CREATION_DATE","CLONEID","TEMPLATEFLAG","CHANGE_BY","CREATED_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","SQLTEXT","DYNAMICREPORTSQLNAME"
              from FG_S_DYNAMICREPORTSQL_ALL_V;

prompt
prompt Creating view FG_S_GROUPSCREW_V
prompt ===============================
prompt
create or replace view fg_s_groupscrew_v as
select to_number(t.formid) as groupscrew_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.GroupsCrewName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as GroupsCrew_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."GROUP_ID",t."PARENTID",t."GROUPSCREWNAME"
      from FG_S_GROUPSCREW_PIVOT t;

prompt
prompt Creating view FG_S_GROUP_V
prompt ==========================
prompt
CREATE OR REPLACE VIEW FG_S_GROUP_V AS
select to_number(t.formid) as group_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.GroupName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as Group_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."GROUPNAME",t."SELECTUSER",t."GROUPTYPE",t."DESCRIPTION",t."SITE_ID",t."FORMCODE_ENTITY",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_GROUP_PIVOT t;

prompt
prompt Creating view FG_S_GROUPSCREW_ALL_V
prompt ===================================
prompt
create or replace view fg_s_groupscrew_all_v as
select t."GROUPSCREW_ID",t."FORM_TEMP_ID",t."GROUPSCREW_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."GROUP_ID",t."PARENTID",t."GROUPSCREWNAME"
--t.* end! edit only the code below...
,pt.GroupName as "GROUP",pt.DESCRIPTION,pt.GROUP_ID as "GROUP_ID_SINGLE"
from FG_S_GROUPSCREW_V t,FG_S_GROUP_V pt
    --  where t.GROUP_ID = pt.GROUP_ID(+)
    where 1=1 and
    instr(',' || t.GROUP_ID || ',',',' || pt.GROUP_ID || ',') > 0;

prompt
prompt Creating view FG_AUTHEN_GROUPSCREW_V
prompt ====================================
prompt
create or replace view fg_authen_groupscrew_v as
select "GROUPSCREW_ID","GROUPSCREW_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","PARENTID","GROUPSCREWNAME","GROUP_ID"
      from FG_S_GROUPSCREW_ALL_V t;

prompt
prompt Creating view FG_S_GROUP_ALL_V
prompt ==============================
prompt
CREATE OR REPLACE VIEW FG_S_GROUP_ALL_V AS
select t."GROUP_ID",t."FORM_TEMP_ID",t."GROUP_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."GROUPNAME",t."SELECTUSER",t."GROUPTYPE",t."DESCRIPTION",t."SITE_ID",t."FORMCODE_ENTITY",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
from FG_S_GROUP_V t;

prompt
prompt Creating view FG_AUTHEN_GROUP_V
prompt ===============================
prompt
create or replace view fg_authen_group_v as
select "GROUP_ID","GROUP_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","DESCRIPTION","GROUPNAME"
      from FG_S_GROUP_ALL_V t;

prompt
prompt Creating view FG_S_LABORATORY_V
prompt ===============================
prompt
create or replace view fg_s_laboratory_v as
select to_number(t.formid) as laboratory_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.LaboratoryName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as Laboratory_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."LAB_MANAGER_ID",t."FORMNUMBERID",t."LABORATORYNAME",t."UNITS_ID",t."SITE_ID"
      from FG_S_LABORATORY_PIVOT t;

prompt
prompt Creating view FG_S_UNITS_V
prompt ==========================
prompt
create or replace view fg_s_units_v as
select to_number(t.formid) as units_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.UnitsName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as Units_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."UNITSNAME",t."SITE_ID",t."CLONEID",t."TEMPLATEFLAG",t."FORMCODE_ENTITY",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_UNITS_PIVOT t;

prompt
prompt Creating view FG_S_SITE_V
prompt =========================
prompt
create or replace view fg_s_site_v as
select to_number(t.formid) as site_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SiteName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as Site_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."CUSTOMER_ID",t."SITENAME",t."CLONEID",t."TEMPLATEFLAG",t."FORMCODE_ENTITY",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_SITE_PIVOT t;

prompt
prompt Creating view FG_S_SITE_ALL_V
prompt =============================
prompt
create or replace view fg_s_site_all_v as
select t."SITE_ID",t."FORM_TEMP_ID",t."SITE_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."CUSTOMER_ID",t."SITENAME",t."CLONEID",t."TEMPLATEFLAG",t."FORMCODE_ENTITY",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
from FG_S_SITE_V t;

prompt
prompt Creating view FG_S_UNITS_ALL_V
prompt ==============================
prompt
create or replace view fg_s_units_all_v as
select t."UNITS_ID",t."FORM_TEMP_ID",t."UNITS_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."UNITSNAME",t."SITE_ID",t."CLONEID",t."TEMPLATEFLAG",t."FORMCODE_ENTITY",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
,s.SITENAME, s.SITE_OBJIDVAL, '{"VAL":"' || t.UnitsName||' ('||s.SiteName||')' || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as unit_with_site_objidval
from FG_S_UNITS_V t,
      FG_S_SITE_ALL_V s
where s.SITE_ID(+) = t.SITE_ID;

prompt
prompt Creating view FG_S_LABORATORY_ALL_V
prompt ===================================
prompt
create or replace view fg_s_laboratory_all_v as
select t."LABORATORY_ID",t."FORM_TEMP_ID",t."LABORATORY_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."LAB_MANAGER_ID",t."FORMNUMBERID",t."LABORATORYNAME",t."UNITS_ID",t."SITE_ID"
--t.* end! edit only the code below...
,u.SITENAME,u.SITE_OBJIDVAL, u.UNITSNAME, u.UNITS_OBJIDVAL
from FG_S_LABORATORY_V t,
     fg_s_units_all_v u
where u.SITE_ID(+) = t.SITE_ID
and u.units_id(+) = t.UNITS_ID;

prompt
prompt Creating view FG_AUTHEN_LABORATORY_V
prompt ====================================
prompt
create or replace view fg_authen_laboratory_v as
select "LABORATORY_ID","LABORATORY_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","LABORATORYNAME"
      from FG_S_LABORATORY_ALL_V t;

prompt
prompt Creating view FG_S_PERMISSIONOBJECT_V
prompt =====================================
prompt
create or replace view fg_s_permissionobject_v as
select to_number(t.formid) as permissionobject_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.PermissionObjectName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as PermissionObject_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."PERMISSIONOBJECTNAME",t."LAB",t."SITE",t."UNIT",t."OBJECTSINHERIT",t."CLONEID",t."TEMPLATEFLAG",t."OBJECTSINHERITONCREATE",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_PERMISSIONOBJECT_PIVOT t;

prompt
prompt Creating view FG_S_PERMISSIONOBJECT_ALL_V
prompt =========================================
prompt
create or replace view fg_s_permissionobject_all_v as
select t."PERMISSIONOBJECT_ID",t."FORM_TEMP_ID",t."PERMISSIONOBJECT_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."PERMISSIONOBJECTNAME",t."LAB",t."SITE",t."UNIT",t."OBJECTSINHERIT",t."CLONEID",t."TEMPLATEFLAG",t."OBJECTSINHERITONCREATE",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
 --,decode(t."OBJECTSINHERIT",null,t."PERMISSIONOBJECTNAME", t."PERMISSIONOBJECTNAME" ||','|| "OBJECTSINHERIT") "PERMISSIONOBJECTNAME_EXTEND",
,'{"VAL":"' ||
replace(
    replace(
        replace(
            replace(
                 regexp_replace(decode(t.PermissionObjectName,'InvItemMaterial','InvItemMaterialCm',t.PermissionObjectName),'^InvItem'),
                'RecipeFormulation',
                'Recipe')
        ,'MaterialCm','Material (Chemical)'),
    'MaterialFr','Material (Formulation)')
,'MaterialPr','Material (Premix)')
|| '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as PermissionObjectName_objidval -- effects only the display in the list (set it also in the fg_s_PermissionSRef_DT_v view)
,t."PERMISSIONOBJECTNAME" || decode(t."OBJECTSINHERITONCREATE",null,'', ',' || t."OBJECTSINHERITONCREATE") || decode(t."OBJECTSINHERIT",null,'', ',' || t."OBJECTSINHERIT") AS  "PERMISSIONOBJECTNAME_GROUP"
              from FG_S_PERMISSIONOBJECT_V t;

prompt
prompt Creating view FG_AUTHEN_PERMISSIONOBJECT_V
prompt ==========================================
prompt
create or replace view fg_authen_permissionobject_v as
select "PERMISSIONOBJECT_ID","FORM_TEMP_ID","PERMISSIONOBJECT_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","PERMISSIONOBJECTNAME","LAB","SITE","UNIT","OBJECTSINHERIT"
              from FG_S_PERMISSIONOBJECT_ALL_V;

prompt
prompt Creating view FG_S_PERMISSIONPOLICY_V
prompt =====================================
prompt
create or replace view fg_s_permissionpolicy_v as
select to_number(t.formid) as permissionpolicy_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.PermissionPolicyName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as PermissionPolicy_objidval,
             t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."CUSTOMER_ID",t."USERROLE_ID",t."PERMISSIONPOLICYNAME",t."POLICYEXPRESSION",t."POLICYPERMISSION"
      from FG_S_PERMISSIONPOLICY_PIVOT t;

prompt
prompt Creating view FG_S_USERROLE_V
prompt =============================
prompt
create or replace view fg_s_userrole_v as
select to_number(t.formid) as userrole_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.UserRoleName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as UserRole_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."CUSTOMER_ID",t."USERROLENAME",t."FORMCODE_ENTITY",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_USERROLE_PIVOT t;

prompt
prompt Creating view FG_S_USERROLE_ALL_V
prompt =================================
prompt
create or replace view fg_s_userrole_all_v as
select t."USERROLE_ID",t."FORM_TEMP_ID",t."USERROLE_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."CUSTOMER_ID",t."USERROLENAME",t."FORMCODE_ENTITY",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
from FG_S_USERROLE_V t;

prompt
prompt Creating view FG_S_PERMISSIONPOLICY_ALL_V
prompt =========================================
prompt
create or replace view fg_s_permissionpolicy_all_v as
select t."PERMISSIONPOLICY_ID",t."FORM_TEMP_ID",t."PERMISSIONPOLICY_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."CUSTOMER_ID",t."USERROLE_ID",t."PERMISSIONPOLICYNAME",t."POLICYEXPRESSION",t."POLICYPERMISSION"
--t.* end! edit only the code below...
      ,c.CUSTOMERNAME, ur.USERROLENAME
from FG_S_PERMISSIONPOLICY_V t,
     fg_s_customer_all_v c,
     fg_s_userrole_all_v ur
where t.USERROLE_ID = ur.USERROLE_ID(+)
and   t.CUSTOMER_ID = c.CUSTOMER_ID(+);

prompt
prompt Creating view FG_AUTHEN_PERMISSIONPOLICY_V
prompt ==========================================
prompt
create or replace view fg_authen_permissionpolicy_v as
select "PERMISSIONPOLICY_ID","FORM_TEMP_ID","PERMISSIONPOLICY_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","PERMISSIONPOLICYNAME"
              from FG_S_PERMISSIONPOLICY_ALL_V t where rownum <= 1;

prompt
prompt Creating view FG_S_PERMISSIONSCHEME_V
prompt =====================================
prompt
create or replace view fg_s_permissionscheme_v as
select to_number(t.formid) as permissionscheme_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.PermissionSchemeName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as PermissionScheme_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."MAINTENANCEFORMLIST",t."PERMISSIONSCHEMENAME",t."PERMISSIONTABLE",t."USERS",t."GROUPSCREW",t."SCREEN"
      from FG_S_PERMISSIONSCHEME_PIVOT t;

prompt
prompt Creating view FG_S_PERMISSIONSCHEME_ALL_V
prompt =========================================
prompt
create or replace view fg_s_permissionscheme_all_v as
select t."PERMISSIONSCHEME_ID",t."FORM_TEMP_ID",t."PERMISSIONSCHEME_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."MAINTENANCEFORMLIST",t."PERMISSIONSCHEMENAME",t."PERMISSIONTABLE",t."USERS",t."GROUPSCREW",t."SCREEN"
--t.* end! edit only the code below...
              from FG_S_PERMISSIONSCHEME_V t;

prompt
prompt Creating view FG_AUTHEN_PERMISSIONSCHEME_V
prompt ==========================================
prompt
create or replace view fg_authen_permissionscheme_v as
select "PERMISSIONSCHEME_ID","FORM_TEMP_ID","PERMISSIONSCHEME_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","PERMISSIONSCHEMENAME","USERS","PERMISSIONTABLE","GROUPSCREW","SCREEN"
              from FG_S_PERMISSIONSCHEME_ALL_V;

prompt
prompt Creating view FG_S_PERMISSIONSREF_V
prompt ===================================
prompt
create or replace view fg_s_permissionsref_v as
select to_number(t.formid) as permissionsref_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.PermissionSRefName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as PermissionSRef_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."PARENTID",t."PERMISSION",t."PERMISSIONSREFNAME",t."LAB_ID",t."UNIT_ID",t."SITE_ID",t."TABLETYPE",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_PERMISSIONSREF_PIVOT t;

prompt
prompt Creating view FG_I_LABALLOWN_V
prompt ==============================
prompt
create or replace view fg_i_laballown_v as
select 10 as "LABORATORY_ID", '{"VAL":"All Labs","ID":"10", "ACTIVE":"1"}' as "LABORATORY_OBJIDVAL",'All Labs' as "LABORATORYNAME",lab.UNITS_ID as "UNITS_ID",lab.SITE_ID,'' as labunit_objidval from FG_S_LABORATORY_all_V lab
union
select 10 as "LABORATORY_ID", '{"VAL":"All Labs","ID":"10", "ACTIVE":"1"}' as "LABORATORY_OBJIDVAL",'All Labs' as "LABORATORYNAME",'10' as "UNITS_ID",'10' as "SITE_ID",'' as labunit_objidval from dual
union
select 11 as "LABORATORY_ID", '{"VAL":"Own","ID":"11", "ACTIVE":"1"}' as "LABORATORY_OBJIDVAL" ,'Own' as "LABORATORYNAME",'11' as "UNITS_ID",'11' as "SITE_ID",'' as labunit_objidval from dual
union
select 12 as "LABORATORY_ID", '{"VAL":"Not Own","ID":"12", "ACTIVE":"1"}' as "LABORATORY_OBJIDVAL",'Not Own' as "LABORATORYNAME" ,'12' as "UNITS_ID", '12' as "SITE_ID",'' as labunit_objidval from dual
union
select 11 as "LABORATORY_ID", '{"VAL":"Own","ID":"11", "ACTIVE":"1"}' as "LABORATORY_OBJIDVAL" ,'Own' as "LABORATORYNAME",lab.UNITS_ID as "UNITS_ID",lab.SITE_ID,'' as labunit_objidval from FG_S_LABORATORY_all_V lab
union
select 12 as "LABORATORY_ID", '{"VAL":"Not Own","ID":"12", "ACTIVE":"1"}' as "LABORATORY_OBJIDVAL",'Not Own' as "LABORATORYNAME",lab.UNITS_ID as "UNITS_ID",lab.SITE_ID,'' as labunit_objidval from FG_S_LABORATORY_all_V lab
union all
select "LABORATORY_ID","LABORATORY_OBJIDVAL","LABORATORYNAME","UNITS_ID","SITE_ID",'{"VAL":"'||LABORATORYNAME||' ('||UNITSNAME||')'||'","ID":"'||LABORATORY_ID||'", "ACTIVE":"'||ACTIVE||'"}' as labunit_objidval from
(select  t."LABORATORY_ID",t."LABORATORY_OBJIDVAL",t."LABORATORYNAME",t."UNITS_ID",t.SITE_ID,t.UNITSNAME,t.ACTIVE
from FG_S_LABORATORY_all_V t
order by LABORATORYNAME);

prompt
prompt Creating view FG_I_PERMISSIONCRUD_V
prompt ===================================
prompt
create or replace view fg_i_permissioncrud_v as
select "NAME","CODE","OBJECTID","PERMISSIONOBJECTNAME" from (
with permission_list as (
-- the code is match getCrudlByPermissionItem java function but not in use in this context
select 'All permissions' as name,'_' as code from dual
union
select 'Create' as name,'C' as code from dual
union
select 'Read' as name,'R' as code from dual
union
select 'Update' as name,'U' as code from dual
union
select 'Approval' as name,'A' as code from dual
union
select 'Cancellation' as name,'D' as code from dual
union
select 'Reopen' as name,'O' as code from dual
)
select distinct
       permission_list.*,
       o.permissionobject_id as "OBJECTID", -- for filtering by the parent object id
       o.PermissionObjectName
from permission_list,
     fg_s_permissionobject_v o
)
where 1=1
--approval only in experiment / Template / RecipeFormulation
and (name <> 'Approval' or name||PermissionObjectName = 'ApprovalExperiment' or name||PermissionObjectName = 'ApprovalTemplate' or name||PermissionObjectName = 'ApprovalRecipeFormulation')
and (name <> 'Cancellation' or name||PermissionObjectName = 'CancellationInvItemMaterial' or name||PermissionObjectName = 'CancellationInvItemMaterialFr' or name||PermissionObjectName = 'CancellationInvItemMaterialPr')
and (name <> 'Reopen' or name||PermissionObjectName = 'ReopenExperiment' or name||PermissionObjectName = 'ReopenRecipeFormulation');

prompt
prompt Creating view FG_I_SITEALLOWN_V
prompt ===============================
prompt
create or replace view fg_i_siteallown_v as
select 10 as "SITE_ID", '{"VAL":"All Sites","ID":"10", "ACTIVE":"1"}' as "SITE_OBJIDVAL",'All Sites' as "SITENAME"   from dual
union all
select 11 as "SITE_ID", '{"VAL":"Own","ID":"11", "ACTIVE":"1"}' as "SITE_OBJIDVAL",'Own' as "SITENAME"   from dual
union all
select 12 as "SITE_ID", '{"VAL":"Not Own","ID":"12", "ACTIVE":"1"}' as "SITE_OBJIDVAL",'Not Own' as "SITENAME"   from dual
union all
select "SITE_ID","SITE_OBJIDVAL","SITENAME" from
(select t."SITE_ID",t."SITE_OBJIDVAL",t."SITENAME"
from FG_S_SITE_V t
order by t."SITENAME");

prompt
prompt Creating view FG_I_UNITALLOWN_V
prompt ===============================
prompt
create or replace view fg_i_unitallown_v as
select 10 as "UNITS_ID", '{"VAL":"All Units","ID":"10", "ACTIVE":"1"}' as "UNITS_OBJIDVAL",'All Units' as "UNITSNAME",u.SITE_ID as "SITE_ID",'' as siteunit_objidval from FG_S_UNITS_V u
union
select 10 as "UNITS_ID", '{"VAL":"All Units","ID":"10", "ACTIVE":"1"}' as "UNITS_OBJIDVAL",'All Units' as "UNITSNAME",'10' as "SITE_ID",'' from dual
union
select 11 as "UNITS_ID", '{"VAL":"Own","ID":"11", "ACTIVE":"1"}' as "UNITS_OBJIDVAL",'Own' as "UNITSNAME", '11' as "SITE_ID",''  from dual
union
select 12 as "UNITS_ID", '{"VAL":"Not Own","ID":"12", "ACTIVE":"1"}' as "UNITS_OBJIDVAL",'Not Own' as "UNITSNAME" , '12' as "SITE_ID",''  from dual
union
select 11 as "UNITS_ID", '{"VAL":"Own","ID":"11", "ACTIVE":"1"}' as "UNITS_OBJIDVAL",'Own' as "UNITSNAME",u.SITE_ID as "SITE_ID",'' from FG_S_UNITS_V u
union
select 12 as "UNITS_ID", '{"VAL":"Not Own","ID":"12", "ACTIVE":"1"}' as "UNITS_OBJIDVAL",'Not Own' as "UNITSNAME" ,u.SITE_ID as "SITE_ID",'' from FG_S_UNITS_V u
union all
select "UNITS_ID","UNITS_OBJIDVAL","UNITSNAME","SITE_ID", '{"VAL":"'||UnitsName||' ('||SITENAME||')'||'","ID":"'||UNITS_ID||'", "ACTIVE":"'||ACTIVE||'"}' as siteunit_objidval from
(select t."UNITS_ID" ,t.UNITS_OBJIDVAL,t.UnitsName ,t."SITE_ID",t.SITENAME,t.ACTIVE
from FG_S_UNITS_all_V t
order by unitsname);

prompt
prompt Creating view FG_S_PERMISSIONSREF_ALL_V
prompt =======================================
prompt
create or replace view fg_s_permissionsref_all_v as
select distinct t."PERMISSIONSREF_ID",t."FORM_TEMP_ID",t."PERMISSIONSREF_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."PARENTID",t."PERMISSION",t."PERMISSIONSREFNAME",t."LAB_ID",t."UNIT_ID",t."SITE_ID",t."TABLETYPE",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
,p."PERMISSIONOBJECTNAME"
,s.SITENAME
,u.UNITSNAME
,l.LABORATORYNAME
,ps.permission_single--regexp_substr(t."PERMISSION", '[^,]+', 1, LEVEL) as permission_single
from FG_S_PERMISSIONSREF_V t ,fg_s_permissionobject_all_v p,fg_i_siteallown_v s,fg_i_unitallown_v u,fg_i_laballown_v l--,fg_s_site_all_v s,fg_s_units_all_v u,fg_s_laboratory_all_v l
 --adib 151018 changed the "connect by" query in the column permission_single above to be accepted from instr
 ,/*(select distinct regexp_substr(t."PERMISSION", '[^,]+', 1, LEVEL) as permission_single
  from fg_s_permissionsref_v t
  CONNECT BY REGEXP_SUBSTR(t."PERMISSION", '[^,]+', 1, LEVEL) IS NOT NULL ) ps*/ --> same result but faster (the origin result also old crudl like delete and list that should be ignored)
  (select distinct name as permission_single from FG_I_PERMISSIONCRUD_V t) ps
where s.SITE_ID(+) = t.SITE_ID
 and u.UNITS_ID(+) = t.UNIT_ID
 and l.LABORATORY_ID(+)= t.LAB_ID
 and p.PERMISSIONOBJECT_ID(+)= t.PERMISSIONSREFNAME
 and instr(','||t.PERMISSION||',',','||ps.permission_single||',')>0 --CONNECT BY REGEXP_SUBSTR(t."PERMISSION", '[^,]+', 1, LEVEL) IS NOT NULL;

prompt
prompt Creating view FG_AUTHEN_PERMISSIONSREF_V
prompt ========================================
prompt
create or replace view fg_authen_permissionsref_v as
select "PERMISSIONSREF_ID","FORM_TEMP_ID","PERMISSIONSREF_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","PARENTID","PERMISSION","PERMISSIONSREFNAME","LAB_ID","UNIT_ID","SITE_ID","TABLETYPE"
              from FG_S_PERMISSIONSREF_ALL_V;

prompt
prompt Creating view FG_AUTHEN_SITE_V
prompt ==============================
prompt
create or replace view fg_authen_site_v as
select "SITE_ID","SITE_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SITENAME"
      from FG_S_SITE_ALL_V t;

prompt
prompt Creating view FG_S_SYSCONFDTCRITERIA_V
prompt ======================================
prompt
create or replace view fg_s_sysconfdtcriteria_v as
select to_number(t.formid) as sysconfdtcriteria_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysConfDTCriteriaName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysConfDTCriteria_objidval,
             t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SYSCONFDTCRITERIANAME",t."ARGFORMCODE",t."ARGSTRUCT",t."SYSCONFSQLPOOL_ID"
      from FG_S_SYSCONFDTCRITERIA_PIVOT t;

prompt
prompt Creating view FG_S_SYSCONFDTCRITERIA_ALL_V
prompt ==========================================
prompt
create or replace view fg_s_sysconfdtcriteria_all_v as
select t."SYSCONFDTCRITERIA_ID",t."FORM_TEMP_ID",t."SYSCONFDTCRITERIA_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SYSCONFDTCRITERIANAME",t."ARGFORMCODE",t."ARGSTRUCT",t."SYSCONFSQLPOOL_ID"
--t.* end! edit only the code below...
              from FG_S_SYSCONFDTCRITERIA_V t;

prompt
prompt Creating view FG_AUTHEN_SYSCONFDTCRITERIA_V
prompt ===========================================
prompt
create or replace view fg_authen_sysconfdtcriteria_v as
select "SYSCONFDTCRITERIA_ID","FORM_TEMP_ID","SYSCONFDTCRITERIA_OBJIDVAL","FORMID","TIMESTAMP","CLONEID","TEMPLATEFLAG","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","SYSCONFDTCRITERIANAME","ARGFORMCODE","ARGSTRUCT","SYSCONFSQLPOOL_ID"
              from FG_S_SYSCONFDTCRITERIA_ALL_V;

prompt
prompt Creating view FG_S_SYSCONFEXCELDATA_V
prompt =====================================
prompt
create or replace view fg_s_sysconfexceldata_v as
select to_number(t.formid) as sysconfexceldata_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysConfExcelDataName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysConfExcelData_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SYSCONFEXCELDATANAME",t."EXCELFILE",t."EXCELDATA"
      from FG_S_SYSCONFEXCELDATA_PIVOT t;

prompt
prompt Creating view FG_S_SYSCONFEXCELDATA_ALL_V
prompt =========================================
prompt
create or replace view fg_s_sysconfexceldata_all_v as
select t."SYSCONFEXCELDATA_ID",t."FORM_TEMP_ID",t."SYSCONFEXCELDATA_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SYSCONFEXCELDATANAME",t."EXCELFILE",t."EXCELDATA"
--t.* end! edit only the code below...
              from FG_S_SYSCONFEXCELDATA_V t;

prompt
prompt Creating view FG_AUTHEN_SYSCONFEXCELDATA_V
prompt ==========================================
prompt
create or replace view fg_authen_sysconfexceldata_v as
select "SYSCONFEXCELDATA_ID","FORM_TEMP_ID","SYSCONFEXCELDATA_OBJIDVAL","FORMID","TIMESTAMP","CREATION_DATE","CLONEID","TEMPLATEFLAG","CHANGE_BY","CREATED_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","SYSCONFEXCELDATANAME","EXCELDATA"
              from FG_S_SYSCONFEXCELDATA_ALL_V;

prompt
prompt Creating view FG_S_SYSCONFPRESAVECALC_V
prompt =======================================
prompt
create or replace view fg_s_sysconfpresavecalc_v as
select to_number(t.formid) as sysconfpresavecalc_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysConfPreSaveCalcName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysConfPreSaveCalc_objidval,
             t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."ARG3",t."RESULTELEMENT",t."ARG4",t."FORMULAORFUNCTION",t."SYSCONFPRESAVECALCNAME",t."ARG5",t."ARGELEMENT",t."ARG2",t."ARG1"
      from FG_S_SYSCONFPRESAVECALC_PIVOT t;

prompt
prompt Creating view FG_S_SYSCONFPRESAVECALC_ALL_V
prompt ===========================================
prompt
create or replace view fg_s_sysconfpresavecalc_all_v as
select t."SYSCONFPRESAVECALC_ID",t."FORM_TEMP_ID",t."SYSCONFPRESAVECALC_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."ARG3",t."RESULTELEMENT",t."ARG4",t."FORMULAORFUNCTION",t."SYSCONFPRESAVECALCNAME",t."ARG5",t."ARGELEMENT",t."ARG2",t."ARG1"
--t.* end! edit only the code below...
              from FG_S_SYSCONFPRESAVECALC_V t;

prompt
prompt Creating view FG_AUTHEN_SYSCONFPRESAVECALC_V
prompt ============================================
prompt
create or replace view fg_authen_sysconfpresavecalc_v as
select "SYSCONFPRESAVECALC_ID","FORM_TEMP_ID","SYSCONFPRESAVECALC_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","ARG3","RESULTELEMENT","ARG4","FORMULAORFUNCTION","SYSCONFPRESAVECALCNAME","ARG5","ARGELEMENT","ARG2","ARG1"
              from FG_S_SYSCONFPRESAVECALC_ALL_V;

prompt
prompt Creating view FG_S_SYSCONFSQLCRITERIA_V
prompt =======================================
prompt
create or replace view fg_s_sysconfsqlcriteria_v as
select to_number(t.formid) as sysconfsqlcriteria_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysConfSQLCriteriaName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysConfSQLCriteria_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SQLDESCRIPTION",t."ADDITIONALMATCHINFO",t."STRUCTLEVEL",t."SQLTEXT",t."SYSCONFSQLCRITERIANAME",t."IGNORE",t."EXECUTATIONTYPE",t."SCREEN",t."ISDEFAULT"
      from FG_S_SYSCONFSQLCRITERIA_PIVOT t;

prompt
prompt Creating view FG_S_SYSCONFSQLCRITERIA_ALL_V
prompt ===========================================
prompt
create or replace view fg_s_sysconfsqlcriteria_all_v as
select t."SYSCONFSQLCRITERIA_ID",t."FORM_TEMP_ID",t."SYSCONFSQLCRITERIA_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SQLDESCRIPTION",t."ADDITIONALMATCHINFO",t."STRUCTLEVEL",t."SQLTEXT",t."SYSCONFSQLCRITERIANAME",t."IGNORE",t."EXECUTATIONTYPE",t."SCREEN",t."ISDEFAULT"
--t.* end! edit only the code below...
,t.SYSCONFSQLCRITERIANAME || '.' || t.STRUCTLEVEL || '.' || t.SCREEN AS infoName
              from FG_S_SYSCONFSQLCRITERIA_V t;

prompt
prompt Creating view FG_AUTHEN_SYSCONFSQLCRITERIA_V
prompt ============================================
prompt
create or replace view fg_authen_sysconfsqlcriteria_v as
select "SYSCONFSQLCRITERIA_ID","FORM_TEMP_ID","SYSCONFSQLCRITERIA_OBJIDVAL","FORMID","TIMESTAMP","CLONEID","TEMPLATEFLAG","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","SQLDESCRIPTION","SYSCONFSQLCRITERIANAME","SQLTEXT","STRUCTLEVEL","IGNORE","EXECUTATIONTYPE","SCREEN","ISDEFAULT","INFONAME"
              from FG_S_SYSCONFSQLCRITERIA_ALL_V;

prompt
prompt Creating view FG_S_SYSCONFSQLPOOL_V
prompt ===================================
prompt
create or replace view fg_s_sysconfsqlpool_v as
select to_number(t.formid) as sysconfsqlpool_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysConfSQLPoolName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysConfSQLPool_objidval,
             t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SQLTYPE",t."SQLDESCRIPTION",t."SYSCONFSQLPOOLNAME",t."SQLTEXT",t."STRUCTLEVEL",t."IGNORE",t."EXECUTATIONTYPE",t."SCREEN",t."ISDEFAULT"
      from FG_S_SYSCONFSQLPOOL_PIVOT t;

prompt
prompt Creating view FG_S_SYSCONFSQLPOOL_ALL_V
prompt =======================================
prompt
create or replace view fg_s_sysconfsqlpool_all_v as
select t."SYSCONFSQLPOOL_ID",t."FORM_TEMP_ID",t."SYSCONFSQLPOOL_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SQLTYPE",t."SQLDESCRIPTION",t."SYSCONFSQLPOOLNAME",t."SQLTEXT",t."STRUCTLEVEL",t."IGNORE",t."EXECUTATIONTYPE",t."SCREEN",t."ISDEFAULT"
--t.* end! edit only the code below...
,t.SYSCONFSQLPOOLNAME || '.' || t.STRUCTLEVEL || '.' || t.SCREEN  AS infoName
              from FG_S_SYSCONFSQLPOOL_V t;

prompt
prompt Creating view FG_AUTHEN_SYSCONFSQLPOOL_V
prompt ========================================
prompt
create or replace view fg_authen_sysconfsqlpool_v as
select "SYSCONFSQLPOOL_ID","FORM_TEMP_ID","SYSCONFSQLPOOL_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","SQLTYPE","SQLDESCRIPTION","SYSCONFSQLPOOLNAME","SQLTEXT","STRUCTLEVEL","EXECUTATIONTYPE","SCREEN","ISDEFAULT"
              from FG_S_SYSCONFSQLPOOL_ALL_V;

prompt
prompt Creating view FG_S_SYSCONFWFNEW_V
prompt =================================
prompt
create or replace view fg_s_sysconfwfnew_v as
select to_number(t.formid) as sysconfwfnew_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysConfWFNewName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysConfWFNew_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."PARAMMAPNAME",t."PARAMMAPVAL",t."SYSCONFWFNEWNAME",t."REMOVEFROMLIST",t."JSONNAME"
      from FG_S_SYSCONFWFNEW_PIVOT t;

prompt
prompt Creating view FG_S_SYSCONFWFNEW_ALL_V
prompt =====================================
prompt
create or replace view fg_s_sysconfwfnew_all_v as
select t."SYSCONFWFNEW_ID",t."FORM_TEMP_ID",t."SYSCONFWFNEW_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."PARAMMAPNAME",t."PARAMMAPVAL",t."SYSCONFWFNEWNAME",t."REMOVEFROMLIST",t."JSONNAME"
                     --t.* end! edit only the code below...
              from FG_S_SYSCONFWFNEW_V t;

prompt
prompt Creating view FG_AUTHEN_SYSCONFWFNEW_V
prompt ======================================
prompt
create or replace view fg_authen_sysconfwfnew_v as
select "SYSCONFWFNEW_ID","FORM_TEMP_ID","SYSCONFWFNEW_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","PARAMMAPNAME","PARAMMAPVAL","SYSCONFWFNEWNAME","REMOVEFROMLIST","JSONNAME"
              from FG_S_SYSCONFWFNEW_ALL_V t where rownum <= 1;

prompt
prompt Creating view FG_S_SYSCONFWFSTATUS_V
prompt ====================================
prompt
create or replace view fg_s_sysconfwfstatus_v as
select to_number(t.formid) as sysconfwfstatus_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysConfWFStatusName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysConfWFStatus_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."WHEREPARTPARMNAME",t."SYSCONFWFSTATUSNAME",t."STATUSFORMCODE",t."STATUSINFCOLUMN",t."JSONNAME"
      from FG_S_SYSCONFWFSTATUS_PIVOT t;

prompt
prompt Creating view FG_S_SYSCONFWFSTATUS_ALL_V
prompt ========================================
prompt
create or replace view fg_s_sysconfwfstatus_all_v as
select t."SYSCONFWFSTATUS_ID",t."FORM_TEMP_ID",t."SYSCONFWFSTATUS_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."WHEREPARTPARMNAME",t."SYSCONFWFSTATUSNAME",t."STATUSFORMCODE",t."STATUSINFCOLUMN",t."JSONNAME"
--t.* end! edit only the code below...
              from FG_S_SYSCONFWFSTATUS_V t;

prompt
prompt Creating view FG_AUTHEN_SYSCONFWFSTATUS_V
prompt =========================================
prompt
create or replace view fg_authen_sysconfwfstatus_v as
select "SYSCONFWFSTATUS_ID","FORM_TEMP_ID","SYSCONFWFSTATUS_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","WHEREPARTPARMNAME","SYSCONFWFSTATUSNAME","STATUSFORMCODE","STATUSINFCOLUMN","JSONNAME"
              from FG_S_SYSCONFWFSTATUS_ALL_V t where rownum <= 1;

prompt
prompt Creating view FG_S_SYSEVENTHANDLERREF_V
prompt =======================================
prompt
create or replace view fg_s_syseventhandlerref_v as
select to_number(t.formid) as syseventhandlerref_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysEventHandlerRefName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysEventHandlerRef_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."HANDLERORDERONFAIL",t."PARENTID",t."TABLETYPE",t."SYSEVENTHANDLERREFNAME",t."HANDLERORDER"
      from FG_S_SYSEVENTHANDLERREF_PIVOT t;

prompt
prompt Creating view FG_S_SYSEVENTHANDLERREF_ALL_V
prompt ===========================================
prompt
create or replace view fg_s_syseventhandlerref_all_v as
select t."SYSEVENTHANDLERREF_ID",t."FORM_TEMP_ID",t."SYSEVENTHANDLERREF_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."HANDLERORDERONFAIL",t."PARENTID",t."TABLETYPE",t."SYSEVENTHANDLERREFNAME",t."HANDLERORDER"
                     --t.* end! edit only the code below...
              from FG_S_SYSEVENTHANDLERREF_V t;

prompt
prompt Creating view FG_AUTHEN_SYSEVENTHANDLERREF_V
prompt ============================================
prompt
create or replace view fg_authen_syseventhandlerref_v as
select "SYSEVENTHANDLERREF_ID","FORM_TEMP_ID","SYSEVENTHANDLERREF_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","HANDLERORDERONFAIL","PARENTID","TABLETYPE","SYSEVENTHANDLERREFNAME","HANDLERORDER"
              from FG_S_SYSEVENTHANDLERREF_ALL_V;

prompt
prompt Creating view FG_S_SYSEVENTHANDLERSET_V
prompt =======================================
prompt
create or replace view fg_s_syseventhandlerset_v as
select to_number(t.formid) as syseventhandlerset_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysEventHandlerSetName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysEventHandlerSet_objidval,
             t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."HANDLERORDERONFAIL",t."HANDLERSETCOMMENT",t."HANDLERORDER",t."SYSEVENTPOINT_ID",t."SYSEVENTHANDLERSETNAME"
      from FG_S_SYSEVENTHANDLERSET_PIVOT t;

prompt
prompt Creating view FG_S_SYSEVENTPOINT_V
prompt ==================================
prompt
create or replace view fg_s_syseventpoint_v as
select to_number(t.formid) as syseventpoint_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysEventPointName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysEventPoint_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."ADDITIONALMATCH",t."FORMCODEMATCH",t."SYSEVENTYPENAME",t."SYSEVENTPOINTNAME"
      from FG_S_SYSEVENTPOINT_PIVOT t;

prompt
prompt Creating view FG_S_SYSEVENTPOINT_ALL_V
prompt ======================================
prompt
create or replace view fg_s_syseventpoint_all_v as
select t."SYSEVENTPOINT_ID",t."FORM_TEMP_ID",t."SYSEVENTPOINT_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."ADDITIONALMATCH",t."FORMCODEMATCH",t."SYSEVENTYPENAME",t."SYSEVENTPOINTNAME"
--t.* end! edit only the code below...
,'{"VAL":"' || t.SYSEVENTYPENAME || '.' || t.FORMCODEMATCH || '.' || t.ADDITIONALMATCH || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SYSEVENTPOINTFullName_objidval,
t.SYSEVENTYPENAME || '.' || t.FORMCODEMATCH || '.' || t.ADDITIONALMATCH AS SYSEVENTPOINTFullName
              from FG_S_SYSEVENTPOINT_V t/*,
              FG_S_SYSEVENTTYPE_ALL_V ET*/
                   --WHERE T.SYSEVENTTYPE_ID = ET.SYSEVENTTYPE_ID(+);

prompt
prompt Creating view FG_S_SYSEVENTHANDLERSET_ALL_V
prompt ===========================================
prompt
create or replace view fg_s_syseventhandlerset_all_v as
select t."SYSEVENTHANDLERSET_ID",t."FORM_TEMP_ID",t."SYSEVENTHANDLERSET_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."HANDLERORDERONFAIL",t."HANDLERSETCOMMENT",t."HANDLERORDER",t."SYSEVENTPOINT_ID",t."SYSEVENTHANDLERSETNAME"
--t.* end! edit only the code below...
,EP.SYSEVENTPOINTFullName
              from FG_S_SYSEVENTHANDLERSET_V t,
                   FG_S_SYSEVENTpoint_ALL_V EP
              WHERE T.SYSEVENTPOINT_ID = EP.SYSEVENTPOINT_ID(+);

prompt
prompt Creating view FG_AUTHEN_SYSEVENTHANDLERSET_V
prompt ============================================
prompt
create or replace view fg_authen_syseventhandlerset_v as
select "SYSEVENTHANDLERSET_ID","FORM_TEMP_ID","SYSEVENTHANDLERSET_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","HANDLERORDERONFAIL","HANDLERSETCOMMENT","HANDLERORDER","SYSEVENTPOINT_ID","SYSEVENTHANDLERSETNAME","SYSEVENTPOINTFULLNAME"
              from FG_S_SYSEVENTHANDLERSET_ALL_V;

prompt
prompt Creating view FG_S_SYSEVENTHANDLER_V
prompt ====================================
prompt
create or replace view fg_s_syseventhandler_v as
select to_number(t.formid) as syseventhandler_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysEventHandlerName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysEventHandler_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."HANDLERVALIDATION",t."CALCARG",t."SYSEVENTHANDLERNAME",t."SYSEVENTPOINTFULLNAME",t."HANDLERORDER",t."HANDLERDESCRIPTION",t."CALCFORMULA",t."HANDLERUNITTEST"
      from FG_S_SYSEVENTHANDLER_PIVOT t;

prompt
prompt Creating view FG_S_SYSEVENTHANDLER_ALL_V
prompt ========================================
prompt
create or replace view fg_s_syseventhandler_all_v as
select t."SYSEVENTHANDLER_ID",t."FORM_TEMP_ID",t."SYSEVENTHANDLER_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."HANDLERVALIDATION",t."CALCARG",t."SYSEVENTHANDLERNAME",t."SYSEVENTPOINTFULLNAME",t."HANDLERORDER",t."HANDLERDESCRIPTION",t."CALCFORMULA",t."HANDLERUNITTEST"
--t.* end! edit only the code below...
      from FG_S_SYSEVENTHANDLER_V t;

prompt
prompt Creating view FG_AUTHEN_SYSEVENTHANDLER_V
prompt =========================================
prompt
create or replace view fg_authen_syseventhandler_v as
select "SYSEVENTHANDLER_ID","FORM_TEMP_ID","SYSEVENTHANDLER_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","HANDLERVALIDATION","SYSEVENTHANDLERNAME","CALCARG","HANDLERORDER","HANDLERDESCRIPTION","HANDLERUNITTEST","CALCFORMULA"
 from FG_S_SYSEVENTHANDLER_ALL_V;

prompt
prompt Creating view FG_S_SYSEVENTHANDLETYPE_V
prompt =======================================
prompt
create or replace view fg_s_syseventhandletype_v as
select to_number(t.formid) as syseventhandletype_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysEventHandleTypeName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysEventHandleType_objidval,
             t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SYSEVENTHANDLETYPENAME",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_SYSEVENTHANDLETYPE_PIVOT t;

prompt
prompt Creating view FG_S_SYSEVENTHANDLETYPE_ALL_V
prompt ===========================================
prompt
create or replace view fg_s_syseventhandletype_all_v as
select t."SYSEVENTHANDLETYPE_ID",t."FORM_TEMP_ID",t."SYSEVENTHANDLETYPE_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SYSEVENTHANDLETYPENAME",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
              from FG_S_SYSEVENTHANDLETYPE_V t;

prompt
prompt Creating view FG_AUTHEN_SYSEVENTHANDLETYPE_V
prompt ============================================
prompt
create or replace view fg_authen_syseventhandletype_v as
select "SYSEVENTHANDLETYPE_ID","FORM_TEMP_ID","SYSEVENTHANDLETYPE_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","SYSEVENTHANDLETYPENAME"
              from FG_S_SYSEVENTHANDLETYPE_ALL_V;

prompt
prompt Creating view FG_AUTHEN_SYSEVENTPOINT_V
prompt =======================================
prompt
create or replace view fg_authen_syseventpoint_v as
select "SYSEVENTPOINT_ID","FORM_TEMP_ID","SYSEVENTPOINT_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","ADDITIONALMATCH","FORMCODEMATCH","SYSEVENTPOINTNAME"
              from FG_S_SYSEVENTPOINT_ALL_V;

prompt
prompt Creating view FG_S_SYSEVENTTYPE_V
prompt =================================
prompt
create or replace view fg_s_syseventtype_v as
select to_number(t.formid) as syseventtype_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.SysEventTypeName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as SysEventType_objidval,
             t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SYSEVENTTYPENAME",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_SYSEVENTTYPE_PIVOT t;

prompt
prompt Creating view FG_S_SYSEVENTTYPE_ALL_V
prompt =====================================
prompt
create or replace view fg_s_syseventtype_all_v as
select t."SYSEVENTTYPE_ID",t."FORM_TEMP_ID",t."SYSEVENTTYPE_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."SYSEVENTTYPENAME",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
              from FG_S_SYSEVENTTYPE_V t;

prompt
prompt Creating view FG_AUTHEN_SYSEVENTTYPE_V
prompt ======================================
prompt
create or replace view fg_authen_syseventtype_v as
select "SYSEVENTTYPE_ID","FORM_TEMP_ID","SYSEVENTTYPE_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","SYSEVENTTYPENAME"
              from FG_S_SYSEVENTTYPE_ALL_V;

prompt
prompt Creating view FG_S_SYSHCODECALC_ALL_V
prompt =====================================
prompt
create or replace view fg_s_syshcodecalc_all_v as
select t."SYSEVENTHANDLER_ID",t."FORM_TEMP_ID",t."SYSEVENTHANDLER_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."HANDLERVALIDATION",t."CALCARG",t."SYSEVENTHANDLERNAME",t."SYSEVENTPOINTFULLNAME",t."HANDLERORDER",t."HANDLERDESCRIPTION",t."CALCFORMULA",t."HANDLERUNITTEST"
--t.* end! edit only the code below...
from FG_S_SYSEVENTHANDLER_V t;

prompt
prompt Creating view FG_AUTHEN_SYSHCODECALC_V
prompt ======================================
prompt
create or replace view fg_authen_syshcodecalc_v as
select "SYSEVENTHANDLER_ID","FORM_TEMP_ID","SYSEVENTHANDLER_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","HANDLERVALIDATION","SYSEVENTHANDLERNAME","CALCARG","HANDLERORDER","HANDLERDESCRIPTION","HANDLERUNITTEST","CALCFORMULA"
              from FG_S_SYSHCODECALC_ALL_V;

prompt
prompt Creating view FG_S_SYSHSIMPLECALC_ALL_V
prompt =======================================
prompt
create or replace view fg_s_syshsimplecalc_all_v as
select t."SYSEVENTHANDLER_ID",t."FORM_TEMP_ID",t."SYSEVENTHANDLER_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."HANDLERVALIDATION",t."CALCARG",t."SYSEVENTHANDLERNAME",t."SYSEVENTPOINTFULLNAME",t."HANDLERORDER",t."HANDLERDESCRIPTION",t."CALCFORMULA",t."HANDLERUNITTEST"
--t.* end! edit only the code below...
--, EP.SYSEVENTYPENAME || '.' || EP.FORMCODEMATCH || '.' || EP.ADDITIONALMATCH AS SYSEVENTPOINTFullName
              from FG_S_SYSEVENTHANDLER_V t/*,
                   FG_S_SYSEVENTPOINT_V EP--,
                 --  FG_S_SYSEVENTTYPE_ALL_V ET
              WHERE 1=1--EP.SYSEVENTTYPENAME = ET.SYSEVENTTYPE_ID(+)
                    and t.SYSEVENTPOINT_ID = ep.syseventpoint_id(+);*/;

prompt
prompt Creating view FG_AUTHEN_SYSHSIMPLECALC_V
prompt ========================================
prompt
create or replace view fg_authen_syshsimplecalc_v as
select "SYSEVENTHANDLER_ID","FORM_TEMP_ID","SYSEVENTHANDLER_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","HANDLERVALIDATION","SYSEVENTHANDLERNAME","CALCARG","HANDLERORDER","HANDLERDESCRIPTION","HANDLERUNITTEST","CALCFORMULA"
              from FG_S_SYSHSIMPLECALC_ALL_V;

prompt
prompt Creating view FG_S_SYSHSIMPLECLAC_ALL_V
prompt =======================================
prompt
create or replace view fg_s_syshsimpleclac_all_v as
select t."SYSEVENTHANDLER_ID",t."FORM_TEMP_ID",t."SYSEVENTHANDLER_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."HANDLERVALIDATION",t."CALCARG",t."SYSEVENTHANDLERNAME",t."SYSEVENTPOINTFULLNAME",t."HANDLERORDER",t."HANDLERDESCRIPTION",t."CALCFORMULA",t."HANDLERUNITTEST"
--t.* end! edit only the code below...
       from  FG_S_SYSEVENTHANDLER_V t;

prompt
prompt Creating view FG_AUTHEN_SYSHSIMPLECLAC_V
prompt ========================================
prompt
create or replace view fg_authen_syshsimpleclac_v as
select "SYSEVENTHANDLER_ID","FORM_TEMP_ID","SYSEVENTHANDLER_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","HANDLERVALIDATION","SYSEVENTHANDLERNAME","CALCARG","HANDLERORDER","HANDLERDESCRIPTION","HANDLERUNITTEST","CALCFORMULA"
              from FG_S_SYSHSIMPLECLAC_ALL_V;

prompt
prompt Creating view FG_S_TESTCUBE_V
prompt =============================
prompt
create or replace view fg_s_testcube_v as
select to_number(t.formid) as testcube_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.TestCubeName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as TestCube_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."TESTCUBENAME"
      from FG_S_TESTCUBE_PIVOT t;

prompt
prompt Creating view FG_S_TESTCUBE_ALL_V
prompt =================================
prompt
create or replace view fg_s_testcube_all_v as
select t."TESTCUBE_ID",t."FORM_TEMP_ID",t."TESTCUBE_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."TESTCUBENAME"
--t.* end! edit only the code below...
              from FG_S_TESTCUBE_V t;

prompt
prompt Creating view FG_AUTHEN_TESTCUBE_V
prompt ==================================
prompt
create or replace view fg_authen_testcube_v as
select "TESTCUBE_ID","FORM_TEMP_ID","TESTCUBE_OBJIDVAL","FORMID","TIMESTAMP","CREATION_DATE","CLONEID","TEMPLATEFLAG","CHANGE_BY","CREATED_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","TESTCUBENAME"
              from FG_S_TESTCUBE_ALL_V;

prompt
prompt Creating view FG_S_TESTDELETION_V
prompt =================================
prompt
create or replace view fg_s_testdeletion_v as
select to_number(t.formid) as testdeletion_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.TestDeletionName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as TestDeletion_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."TESTDELETIONNAME"
      from FG_S_TESTDELETION_PIVOT t;

prompt
prompt Creating view FG_S_TESTDELETION_ALL_V
prompt =====================================
prompt
create or replace view fg_s_testdeletion_all_v as
select t."TESTDELETION_ID",t."FORM_TEMP_ID",t."TESTDELETION_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."TESTDELETIONNAME"
--t.* end! edit only the code below...
              from FG_S_TESTDELETION_V t;

prompt
prompt Creating view FG_AUTHEN_TESTDELETION_V
prompt ======================================
prompt
create or replace view fg_authen_testdeletion_v as
select "TESTDELETION_ID","FORM_TEMP_ID","TESTDELETION_OBJIDVAL","FORMID","TIMESTAMP","CREATION_DATE","CLONEID","TEMPLATEFLAG","CHANGE_BY","CREATED_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","TESTDELETIONNAME"
              from FG_S_TESTDELETION_ALL_V;

prompt
prompt Creating view FG_S_TESTFORM_V
prompt =============================
prompt
create or replace view fg_s_testform_v as
select to_number(t.formid) as testform_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.TestFormName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as TestForm_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."RT1",t."TESTFORMNAME",t."APPROVER_ID"
      from FG_S_TESTFORM_PIVOT t;

prompt
prompt Creating view FG_S_TESTFORM_ALL_V
prompt =================================
prompt
create or replace view fg_s_testform_all_v as
select t."TESTFORM_ID",t."FORM_TEMP_ID",t."TESTFORM_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."RT1",t."TESTFORMNAME",t."APPROVER_ID"
--t.* end! edit only the code below...
              from FG_S_TESTFORM_V t;

prompt
prompt Creating view FG_AUTHEN_TESTFORM_V
prompt ==================================
prompt
create or replace view fg_authen_testform_v as
select "TESTFORM_ID","FORM_TEMP_ID","TESTFORM_OBJIDVAL","FORMID","TIMESTAMP","CREATION_DATE","CLONEID","TEMPLATEFLAG","CHANGE_BY","CREATED_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","TESTFORMNAME"
              from FG_S_TESTFORM_ALL_V;

prompt
prompt Creating view FG_AUTHEN_UNITS_V
prompt ===============================
prompt
create or replace view fg_authen_units_v as
select "UNITS_ID","UNITS_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","UNITSNAME"
      from FG_S_UNITS_ALL_V t;

prompt
prompt Creating view FG_S_UNITTESTCONFIG_V
prompt ===================================
prompt
create or replace view fg_s_unittestconfig_v as
select to_number(t.formid) as unittestconfig_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.UnitTestConfigName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as UnitTestConfig_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."UNITTESTCONFIGCOMMENTS",t."GROUPNAME",t."UNITTESTCONFIGNAME",t."UNITTESTACTION",t."ORDEROFEXECUTION",t."IGNORETEST",t."WAITINGTIME",t."ENTITYIMPNAME",t."TESTINGFORMCODE",t."FIELDVALUE"
      from FG_S_UNITTESTCONFIG_PIVOT t;

prompt
prompt Creating view FG_S_UNITTESTCONFIG_ALL_V
prompt =======================================
prompt
create or replace view fg_s_unittestconfig_all_v as
select t."UNITTESTCONFIG_ID",t."FORM_TEMP_ID",t."UNITTESTCONFIG_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."UNITTESTCONFIGCOMMENTS",t."GROUPNAME",t."UNITTESTCONFIGNAME",t."UNITTESTACTION",t."ORDEROFEXECUTION",t."IGNORETEST",t."WAITINGTIME",t."ENTITYIMPNAME",t."TESTINGFORMCODE",t."FIELDVALUE"
--t.* end! edit only the code below...
              from FG_S_UNITTESTCONFIG_V t;

prompt
prompt Creating view FG_AUTHEN_UNITTESTCONFIG_V
prompt ========================================
prompt
create or replace view fg_authen_unittestconfig_v as
select "UNITTESTCONFIG_ID","FORM_TEMP_ID","UNITTESTCONFIG_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","UNITTESTCONFIGNAME"
              from FG_S_UNITTESTCONFIG_ALL_V;

prompt
prompt Creating view FG_S_UNITTESTGROUP_V
prompt ==================================
prompt
create or replace view fg_s_unittestgroup_v as
select to_number(t.formid) as unittestgroup_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.UnitTestGroupName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as UnitTestGroup_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."UNITTESTGROUPNAME",t."ORDEROFEXECUTION",t."IGNORE",t."UNITTESTLEVELS",t."COMMENTS",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_UNITTESTGROUP_PIVOT t;

prompt
prompt Creating view FG_S_UNITTESTGROUP_ALL_V
prompt ======================================
prompt
create or replace view fg_s_unittestgroup_all_v as
select t."UNITTESTGROUP_ID",t."FORM_TEMP_ID",t."UNITTESTGROUP_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."UNITTESTGROUPNAME",t."ORDEROFEXECUTION",t."IGNORE",t."UNITTESTLEVELS",t."COMMENTS",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
                     ,'aaa' as DUMMY
              from FG_S_UNITTESTGROUP_V t;

prompt
prompt Creating view FG_AUTHEN_UNITTESTGROUP_V
prompt =======================================
prompt
create or replace view fg_authen_unittestgroup_v as
select "UNITTESTGROUP_ID","FORM_TEMP_ID","UNITTESTGROUP_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","UNITTESTGROUPNAME"
              from FG_S_UNITTESTGROUP_ALL_V;

prompt
prompt Creating view FG_S_UOMTYPE_V
prompt ============================
prompt
create or replace view fg_s_uomtype_v as
select to_number(t.formid) as uomtype_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.UOMTypeName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as UOMType_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."UOMTYPENAME",t."FORMCODE_ENTITY",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_UOMTYPE_PIVOT t;

prompt
prompt Creating view FG_S_UOMTYPE_ALL_V
prompt ================================
prompt
create or replace view fg_s_uomtype_all_v as
select t."UOMTYPE_ID",t."FORM_TEMP_ID",t."UOMTYPE_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."UOMTYPENAME",t."FORMCODE_ENTITY",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
              from FG_S_UOMTYPE_V t;

prompt
prompt Creating view FG_AUTHEN_UOMTYPE_V
prompt =================================
prompt
create or replace view fg_authen_uomtype_v as
select "UOMTYPE_ID","FORM_TEMP_ID","UOMTYPE_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","SESSIONID","ACTIVE","FORMCODE","UOMTYPENAME"
              from FG_S_UOMTYPE_ALL_V t where rownum <= 1;

prompt
prompt Creating view FG_S_UOM_V
prompt ========================
prompt
create or replace view fg_s_uom_v as
select to_number(t.formid) as uom_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.UOMName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as UOM_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."ISNORMAL",t."FACTOR",t."PRECISION",t."UOMNAME",t."TYPE",t."FORMCODE_ENTITY",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_UOM_PIVOT t;

prompt
prompt Creating view FG_S_UOM_ALL_V
prompt ============================
prompt
create or replace view fg_s_uom_all_v as
select t."UOM_ID",t."FORM_TEMP_ID",t."UOM_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."ISNORMAL",t."FACTOR",t."PRECISION",t."UOMNAME",t."TYPE",t."FORMCODE_ENTITY",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
, uomtype.UOMTYPENAME,t.TYPE as "UOMTYPE_ID",uomtype.UOMTYPENAME as UOM_TYPE,
first_value(t."UOM_ID") over (partition by uomtype.UOMTYPE_ID order by nvl(t.ISNORMAL,0) desc nulls last) as "UOM_NORMAL_ID"
from FG_S_UOM_V t, fg_s_uomtype_all_v uomtype
where t.TYPE = uomtype.UOMTYPE_ID;

prompt
prompt Creating view FG_AUTHEN_UOM_V
prompt =============================
prompt
create or replace view fg_authen_uom_v as
select "UOM_ID","UOM_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","UOMNAME"
      from FG_S_UOM_ALL_V t;

prompt
prompt Creating view FG_S_USERGUIDEPOOL_V
prompt ==================================
prompt
create or replace view fg_s_userguidepool_v as
select to_number(t.formid) as userguidepool_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.UserGuidePoolName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as UserGuidePool_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."USERGUIDEDESCRIPTION",t."USERGUIDEFILE",t."ITEMORDER",t."USERGUIDEPOOLNAME"
      from FG_S_USERGUIDEPOOL_PIVOT t;

prompt
prompt Creating view FG_FILES_FAST_V
prompt =============================
prompt
create or replace view fg_files_fast_v as
select "FILE_ID","FILE_NAME","CONTENT_TYPE",t.FILE_DISPLAY_ID, t.FILE_CHEM_ID
from FG_FILES t;

prompt
prompt Creating view FG_S_USERGUIDEPOOL_ALL_V
prompt ======================================
prompt
create or replace view fg_s_userguidepool_all_v as
select t."USERGUIDEPOOL_ID",t."FORM_TEMP_ID",t."USERGUIDEPOOL_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."USERGUIDEDESCRIPTION",t."USERGUIDEFILE",t."ITEMORDER",t."USERGUIDEPOOLNAME"
--t.* end! edit only the code below...
      ,f.FILE_NAME, f.CONTENT_TYPE,f.FILE_ID
              from FG_S_USERGUIDEPOOL_V t,
                   fg_files_fast_v f
where t.USERGUIDEFILE = f.FILE_ID(+);

prompt
prompt Creating view FG_AUTHEN_USERGUIDEPOOL_V
prompt =======================================
prompt
create or replace view fg_authen_userguidepool_v as
select "USERGUIDEPOOL_ID","FORM_TEMP_ID","USERGUIDEPOOL_OBJIDVAL","FORMID","TIMESTAMP","CREATION_DATE","CLONEID","TEMPLATEFLAG","CHANGE_BY","CREATED_BY","SESSIONID","ACTIVE","FORMCODE_ENTITY","FORMCODE","USERGUIDEDESCRIPTION","USERGUIDEFILE","USERGUIDEPOOLNAME"
              from FG_S_USERGUIDEPOOL_ALL_V;

prompt
prompt Creating view FG_AUTHEN_USERROLE_V
prompt ==================================
prompt
create or replace view fg_authen_userrole_v as
select "USERROLE_ID","USERROLE_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","USERROLENAME"
      from FG_S_USERROLE_ALL_V t;

prompt
prompt Creating view FG_S_USERSCREW_V
prompt ==============================
prompt
create or replace view fg_s_userscrew_v as
select to_number(t.formid) as userscrew_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.UsersCrewName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as UsersCrew_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."USERSCREWNAME",t."PARENTID",t."USER_ID",t."DISABLED"
      from FG_S_USERSCREW_PIVOT t;

prompt
prompt Creating view FG_S_USER_V
prompt =========================
prompt
create or replace view fg_s_user_v as
select to_number(t.formid) as user_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.UserName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as User_objidval,
             t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."FIRSTNAME",t."USERNAME",t."POSITION",t."CHANGEPASSWORD",t."LASTNAME",t."PERMISSIONTABLE",t."TEAMLEADER_ID",t."CUSTOMER_ID",t."DELETED",t."SENSITIVITYLEVEL_ID",t."LOCKED",t."USERROLE_ID",t."USERLDAP",t."PASSWORDDATE",t."MESSAGECHECKINTERVAL",t."LASTNOTIFICATIONCHECK",t."LABORATORY_ID",t."GROUPSCREW",t."UNIT_ID",t."CHGPASSWORDDATE",t."LAST_BREADCRUMB_LINK",t."PASSWORD",t."SITE_ID",t."LASTRETRY",t."RETRYCOUNT",t."EMAIL",t."LASTPASSWORDDATE"
      from FG_S_USER_PIVOT t;

prompt
prompt Creating view FG_S_SENSITIVITYLEVEL_V
prompt =====================================
prompt
create or replace view fg_s_sensitivitylevel_v as
select to_number(t.formid) as sensitivitylevel_id,
             t.formid || decode(nvl(t.sessionId,'-1'),'-1',null, '-' || t.sessionId) || decode(nvl(t.active,1),0,'-0') as form_temp_id,
             '{"VAL":"' || t.sensitivityLevelName || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as sensitivityLevel_objidval,
             t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."CUSTOMER_ID",t."SENSITIVITYLEVELNAME",t."DESCRIPTION",t."FORMCODE_ENTITY",t."SENSITIVITYLEVELORDER",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
      from FG_S_SENSITIVITYLEVEL_PIVOT t;

prompt
prompt Creating view FG_S_SENSITIVITYLEVEL_ALL_V
prompt =========================================
prompt
create or replace view fg_s_sensitivitylevel_all_v as
select t."SENSITIVITYLEVEL_ID",t."FORM_TEMP_ID",t."SENSITIVITYLEVEL_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE",t."CUSTOMER_ID",t."SENSITIVITYLEVELNAME",t."DESCRIPTION",t."FORMCODE_ENTITY",t."SENSITIVITYLEVELORDER",t."CLONEID",t."TEMPLATEFLAG",t."CREATED_BY",t."CREATION_DATE"
--t.* end! edit only the code below...
              from FG_S_SENSITIVITYLEVEL_V t;

prompt
prompt Creating view FG_S_USER_ALL_V
prompt =============================
prompt
create or replace view fg_s_user_all_v as
select t."USER_ID",t."FORM_TEMP_ID",t."USER_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."FIRSTNAME",t."USERNAME",t."POSITION",t."CHANGEPASSWORD",t."LASTNAME",t."PERMISSIONTABLE",t."TEAMLEADER_ID",t."CUSTOMER_ID",t."DELETED",t."SENSITIVITYLEVEL_ID",t."LOCKED",t."USERROLE_ID",t."USERLDAP",t."PASSWORDDATE",t."MESSAGECHECKINTERVAL",t."LASTNOTIFICATIONCHECK",t."LABORATORY_ID",t."GROUPSCREW",t."UNIT_ID",t."CHGPASSWORDDATE",t."LAST_BREADCRUMB_LINK",t."PASSWORD",t."SITE_ID",t."LASTRETRY",t."RETRYCOUNT",t."EMAIL",t."LASTPASSWORDDATE"
--t.* end! edit only the code below...
,t1.UserRoleName,lab.SITENAME,unit.UNITSNAME,lab.LABORATORYNAME,
       '{"VAL":"' || nvl(t.FIRSTNAME,t.UserName) || ' ' || t.LASTNAME || '","ID":"' || t.formid || '", "ACTIVE":"' || nvl(t.active,1) || '"}' as UserFullName_objidval
       ,sens.SENSITIVITYLEVELNAME
       ,sens.SENSITIVITYLEVELORDER
from fg_s_user_v t,
     Fg_s_Userrole_v t1,
     FG_S_LABORATORY_ALL_V lab,
     fg_s_units_all_v unit,
     fg_s_sensitivitylevel_all_v sens
where t.userrole_id = t1.userrole_id(+)
and   t.LABORATORY_ID = lab.LABORATORY_ID(+)
and   t.UNIT_ID =  unit.UNITS_ID(+)
and   t.SENSITIVITYLEVEL_ID = sens.SENSITIVITYLEVEL_ID(+);

prompt
prompt Creating view FG_S_USERSCREW_ALL_V
prompt ==================================
prompt
create or replace view fg_s_userscrew_all_v as
select t."USERSCREW_ID",t."FORM_TEMP_ID",t."USERSCREW_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CREATION_DATE",t."CLONEID",t."TEMPLATEFLAG",t."CHANGE_BY",t."CREATED_BY",t."SESSIONID",t."ACTIVE",t."FORMCODE_ENTITY",t."FORMCODE",t."USERSCREWNAME",t."PARENTID",t."USER_ID",t."DISABLED"
--t.* end! edit only the code below...
,pt.LABORATORYNAME, pt.UNITSNAME,pt.SITENAME ,pt.POSITION, pt.USERNAME, pt.USER_ID as "USER_ID_SINGLE" --USER_ID_SINGLE used for single user id id
 ,decode(instr(',' || t.DISABLED|| ',',',' || pt.USER_ID || ','),0,0,1) as "isDisabled"
from FG_S_USERSCREW_V t ,fg_s_user_all_v pt
where 1=1 --',' || t.USER_ID || ',' like '%,' || pt.user_id || ',%'
and instr(',' || t.USER_ID || ',',',' || pt.user_id || ',') > 0;

prompt
prompt Creating view FG_AUTHEN_USERSCREW_V
prompt ===================================
prompt
create or replace view fg_authen_userscrew_v as
select t.FORM_TEMP_ID,"USERSCREW_ID","USERSCREW_OBJIDVAL","FORMID","TIMESTAMP","CHANGE_BY","PARENTID","USERSCREWNAME","USER_ID","DISABLED"
      from FG_S_USERSCREW_ALL_V t;

prompt
prompt Creating view FG_AUTHEN_USER_V
prompt ==============================
prompt
create or replace view fg_authen_user_v as
select t."USER_ID",t."FORM_TEMP_ID",t."USER_OBJIDVAL",t."FORMID",t."TIMESTAMP",t."CHANGE_BY",t."SESSIONID",t."ACTIVE",t."PASSWORD",t."FIRSTNAME",t."USERLDAP",t."USERNAME",t."PASSWORDDATE",t."CHGPASSWORDDATE",t."POSITION",t."LASTNAME",t."USERROLE_ID",t."LASTRETRY",t."EMAIL",t."DELETED",t."RETRYCOUNT",t."CHANGEPASSWORD",t."LOCKED",t."LASTPASSWORDDATE",t."LABORATORY_ID",t."UNIT_ID",t."SITE_ID",t."USERROLENAME",t."SITENAME",t."UNITSNAME",t."LABORATORYNAME",t."USERFULLNAME_OBJIDVAL"
      from FG_S_USER_ALL_V t;

prompt
prompt Creating view FG_FORMDATA_V
prompt ===========================
prompt
CREATE OR REPLACE VIEW FG_FORMDATA_V AS
select formcode_table -- <formcode or NA;<table name or NA>;<view source data (in case if table contains clob's type fiels) or NA (in this case the data taken from table name)>;comment
from (
      SELECT distinct f.formcode || ';' || 'FG_S_' || upper(f.formcode_entity) || '_PIVOT' || ';NA' || ';NA' as formcode_table, 100 order_
      FROM FG_FORM F
      WHERE F.FORM_TYPE = 'MAINTENANCE'
      and f.group_name in ('_System Event Handler','_System Configuration Pool','_System Configuration Report'/* ,'_System Unit Test Pool'*/) -- System Unit Test Pool is config in each ENV. - we can pass it easly by copy the relevant tests
      UNION ALL
      SELECT 'NA;FG_FORM;NA;NA', 1 order_  FROM DUAL
      UNION ALL
      --FG_FORMENTITY using pde (TABLE AS NA)
      /*SELECT 'NA;NA;NA;FG_FORMENTITY - NEED TO BE IMPORT BY PDE FILE (in comply is made automatically in SET_POST_SCRIPT_VERSION_DATA as part of this script)' formcode_table, 0 order_ FROM DUAL
      UNION ALL*/
      SELECT 'NA;FG_FORMENTITY;NA;NA' formcode_table, 10 order_ FROM DUAL
      UNION ALL
      SELECT 'NA;FG_RESOURCE;NA;NA;', 2 order_ FROM DUAL
      /*UNION ALL
      SELECT 'NA;D_NOTIFICATION_CRITERIA;D_NOTIFICATION_CRITERIA_V;NA', 3 order_ FROM DUAL
      UNION ALL
      SELECT 'NA;D_NOTIFICATION_MESSAGE;D_NOTIFICATION_MESSAGE_V;NA', 4 order_ FROM DUAL
      UNION ALL
      SELECT 'NA;P_NOTIFICATION_LISTADDRESGROUP;P_NOTIFICATION_LISTADDRESGRO_V;NA', 5 order_ FROM DUAL
      UNION ALL
      SELECT 'NA;P_NOTIFICATION_MODULE_TYPE;P_NOTIFICATION_MODULE_TYPE_V;NA', 6 order_ FROM DUAL
      UNION ALL
      SELECT 'NA;D_NOTIFICATION_ADDRESSEE;D_NOTIFICATION_ADDRESSEE_V;NA', 7 order_ FROM DUAL
      UNION ALL
      SELECT 'NA;P_NOTIFICATION_LISTSYSTEMDATA;P_NOTIFICATION_LISTSYSTEMDAT_V;NA', 8 order_ FROM DUAL*/
      UNION ALL
      SELECT 'NA;FG_REPORT_LIST;FG_REPORT_LIST_V;NA', 9 order_ FROM DUAL
      )
order by order_;

prompt
prompt Creating view FG_FORMENTITY_COL_LEN_V
prompt =====================================
prompt
create or replace view fg_formentity_col_len_v as
select distinct t.entityimpclass, t1.formcode, t.entityimpcode, t1.Formcode_Entity,
                decode(t.entityimpclass,'ElementParamMonitoringImp',4000,'ElementDynamicParamsImp',4000,'ElementTextareaImp',4000
                ,'ElementDataTableApiImp',nvl2(REGEXP_SUBSTR(t1.formcode_entity,
                                   '^SampleSelect|ColumnSelect|BatchSelect|RequestSelect|InstrumentSelect$')
                                       ,4000,500),500) as col_length --ElementParamMonitoringImp,ElementDynamicParamsImp,ElementTextareaImp
from FG_FORMENTITY t,
     fG_FORM t1
where t.formcode = t1.formcode;

prompt
prompt Creating view FG_FORMENTITY_V
prompt =============================
prompt
CREATE OR REPLACE VIEW FG_FORMENTITY_V AS
SELECT "ID",
          "FORMCODE",
          "NUMBEROFORDER",
          "ENTITYTYPE",
          "ENTITYIMPCODE",
          "ENTITYIMPCLASS",
          SUBSTR("ENTITYIMPINIT",2,LENGTH("ENTITYIMPINIT") - 2) AS "ENTITYIMPINIT",
          --replace(json_ENTITYIMPINIT,'","','", "') AS "ENTITYIMPINIT",
          json_ENTITYIMPINIT
FROM
(
  select  "ID",
          "FORMCODE",
          "NUMBEROFORDER",
          "ENTITYTYPE",
          "ENTITYIMPCODE",
          "ENTITYIMPCLASS",
          REGEXP_REPLACE (
                          REGEXP_REPLACE(
                                          t.ENTITYIMPINIT,
                                          '","',
                                          ', '
                                          ),
                          '"',
                          ''
                          ) as  "ENTITYIMPINIT", --for display
         /* REGEXP_REPLACE(
                        t.ENTITYIMPINIT,
                        '","',
                        ', '
                        ) as  "ENTITYIMPINIT", --for display*/
         t.ENTITYIMPINIT as json_ENTITYIMPINIT
  from fg_formentity t
  --where t.entityimpclass <> 'ElementDataTableWebixImp'
);

prompt
prompt Creating view FG_I_FORMENTITY_V
